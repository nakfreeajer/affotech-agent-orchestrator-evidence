import { createHash } from 'node:crypto';

export const DOCUMENTATION_TARGETS = Object.freeze([
  'docs/CURRENT_STATE.md',
  'docs/PROJECT_HISTORY.md',
  'docs/DECISIONS.md',
  'docs/BUGS_AND_LESSONS.md',
  'docs/ARCHITECTURE.md'
]);

const clone = (value) => value === undefined ? undefined : JSON.parse(JSON.stringify(value));
const object = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
const text = (value) => typeof value === 'string' && value.length > 0;
const fail = (reason) => Object.freeze({ valid: false, classification: 'CURATOR_DOCUMENT_RENDERER_INVALID', reasonCodes: [reason], mutationAuthorized: false, cursorAdvanceAuthorized: false });
const sha256 = (value) => createHash('sha256').update(value, 'utf8').digest('hex');
const stable = (value) => JSON.stringify(value, Object.keys(value).sort());
const line = (value = '') => `${value}\n`;
const refLines = (events) => events.map((event) => `- Sequence ${event.sequence}: ${event.eventType} — ${event.eventId} — ${event.detailsRef}`).join('\n');
const metadata = (input) => [
  `Project: ${input.projectId}`,
  `Projection input boundary: ${input.sourceRef}`,
  `Covered event range: ${input.eventRange.first}-${input.eventRange.last}`,
  'Status: PENDING_ARCHITECT_SEMANTIC_ACCEPTANCE',
  'Human-readable projection only; durable GitHub evidence and Architect decisions remain machine authority.'
].join('\n');
const requireInput = (input) => {
  if (!object(input) || input.projectId !== 'affotech-agent-orchestrator' || !text(input.sourceRef) || !object(input.eventRange) || input.eventRange.first !== 1 || input.eventRange.last !== 15 || !Array.isArray(input.events) || input.events.length !== 15 || !object(input.acceptedSource) || !object(input.semantic) || !Array.isArray(input.causalChains)) return fail('REQUIRED_STRUCTURED_INPUT_MISSING');
  if (!DOCUMENTATION_TARGETS.every((target) => input.targets?.includes(target))) return fail('BOUND_TARGETS_INVALID');
  if (input.events.some((event, index) => event.sequence !== index + 1 || !text(event.eventId) || !text(event.eventType) || !text(event.detailsRef))) return fail('EVENT_PROVENANCE_INVALID');
  const s = input.semantic;
  if (s.orch000063 !== 'BLOCKED' || s.orch000064 !== 'ACCEPTED_ROOT_CAUSE_NOT_SOURCE' || s.orch000065 !== 'CURRENT_ACCEPTED_SOURCE' || s.orch000066 !== 'ACCEPTED_RECOVERY' || s.cursor !== 'NOT_CONSUMED') return fail('SEMANTIC_TRUTH_INPUT_INVALID');
  if (!text(input.acceptedSource.publicationId) || input.acceptedSource.publicationId !== 'GH-PUB-065-PROJECT-MEMORY-LIVE-EVENT-CUTOVER-REPAIR-000001' || input.acceptedSource.files !== 95 || input.acceptedSource.fullTests !== '693/0/0' || !text(input.acceptedSource.manifestSha256) || !text(input.acceptedSource.archiveSha256)) return fail('ACCEPTED_SOURCE_INPUT_INVALID');
  return null;
};

function renderCurrentState(input) {
  return [metadata(input), '', '# Current State', '', '## Accepted truth', '', '- Durable GitHub evidence and the chronological project-event ledger are reconstructable project memory.', `- The canonical event ledger is coherent through sequence ${input.eventRange.last} at the frozen boundary.`, `- ${input.acceptedSource.publicationId} is the current accepted source baseline: ${input.acceptedSource.files} files; full tests ${input.acceptedSource.fullTests}.`, `- Accepted source manifest SHA-256: ${input.acceptedSource.manifestSha256}.`, `- Accepted source archive SHA-256: ${input.acceptedSource.archiveSha256}; archive size: ${input.acceptedSource.archiveSize} bytes.`, '- ORCH-000066 live event cutover recovery is Architect-accepted.', '- Curator remains optional and on-demand.', '- No live Curator cursor had consumed events at the frozen boundary.', '- No AFFOTECH integration or access is authorized by this projection.', '', '## Boundary', '', '- ORCH-000063 remains blocked historical evidence.', '- ORCH-000064 is accepted root-cause analysis, not an accepted source.', ''].join('\n');
}
function renderHistory(input) { return [metadata(input), '', '# Project History', '', ...input.causalChains.map((chain) => `## ${chain.label}\n\n${chain.summary}\n\n${refLines(input.events.filter((event) => chain.sequences.includes(event.sequence)))}`), '', 'Failed, ambiguous, and blocked paths remain visible as history; none are rewritten as success.', ''].join('\n'); }
function renderDecisions(input) { const selected = input.events.filter((event) => [1, 5, 8, 11, 15].includes(event.sequence)); return [metadata(input), '', '# Architect Decisions', '', ...selected.map((event) => `## Sequence ${event.sequence}: ${event.eventType}\n\n- Identity: ${event.producerEventKey}\n- Classification: ${input.decisionClassifications[String(event.sequence)]}\n- Evidence: ${event.detailsRef}\n- Event: ${event.eventId}`), '', 'Machine decision records remain authoritative. Sequence 5 BLOCKED remains explicitly visible.', ''].join('\n'); }
function renderLessons(input) { return [metadata(input), '', '# Bugs and Lessons', '', '## Accepted root causes', '', '- SOURCE_ACCEPTED identity collision: decisionId was selected before acceptedSourcePublicationId.', '- Stored-record self-hash validation defect: validateStored hashed a record containing recordSha256.', '', '## Accepted countermeasures', '', '- SOURCE_ACCEPTED uses a distinct deterministic identity binding.', '- Stored-record validation excludes recordSha256 from its canonical self-hash.', '', '## Fail-closed lessons', '', '- Do not blindly retry after an ambiguous mutation.', '- Reconcile read-only first.', '- Preserve a valid canonical prefix.', '', `Evidence: ${input.events.find((event) => event.sequence === 7).detailsRef}; ${input.events.find((event) => event.sequence === 10).detailsRef}.`, ''].join('\n'); }
function renderArchitecture(input) { return [metadata(input), '', '# Architecture', '', '- Durable detailed evidence remains machine authority.', '- The project-event ledger is a chronological projection and index over that evidence.', '- First-hand producer ownership and deterministic producerEventKey identity provide event integrity and idempotency.', '- Immutable event records and a compare-and-swap index preserve the canonical chain.', '- Curator is an optional, on-demand human-readable documentation projection.', '- A Curator cursor can advance only after documentation preservation/readback and Architect semantic acceptance.', `- The accepted source is ${input.acceptedSource.publicationId}; the accepted event-ledger state ends at sequence ${input.eventRange.last}.`, '', 'This does not claim continuous automatic Curator operation or a live cursor.', ''].join('\n'); }

export function renderDocumentationProjection(input = {}) {
  const invalid = requireInput(input); if (invalid) return invalid;
  const renderers = [renderCurrentState, renderHistory, renderDecisions, renderLessons, renderArchitecture];
  const contents = renderers.map((render) => render(input)).map((content) => content.replace(/\r\n/g, '\n').replace(/\n*$/, '\n'));
  const documents = Object.fromEntries(DOCUMENTATION_TARGETS.map((target, index) => [target, Object.freeze({ path: target, content: contents[index], sha256: sha256(contents[index]) })]));
  const digest = sha256(stable(Object.fromEntries(DOCUMENTATION_TARGETS.map((target) => [target, documents[target].sha256]))));
  return Object.freeze({ valid: true, classification: 'CURATOR_DOCUMENTATION_PROJECTION_RENDERED', projectId: input.projectId, sourceRef: input.sourceRef, eventRange: clone(input.eventRange), documents: Object.freeze(documents), documentPaths: Object.freeze([...DOCUMENTATION_TARGETS]), projectionDigest: digest, cursorAdvanceAuthorized: false, mutationAuthorized: false, retryAuthorized: false });
}

export const curatorDocumentRenderer = Object.freeze({ DOCUMENTATION_TARGETS, renderDocumentationProjection });
