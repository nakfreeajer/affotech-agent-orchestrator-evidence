import assert from 'node:assert/strict';
import { test } from 'node:test';
import { createGitHubContentsRuntimeClient } from '../src/host/github-contents-runtime-client.js';

const json = (value) => Buffer.from(`${JSON.stringify(value, null, 2)}\n`, 'utf8').toString('base64');
const missing = () => Object.assign(new Error('not found'), { code: 'NOT_FOUND', status: 404 });
function fakeRepository(initial = {}, options = {}) {
  const files = new Map(Object.entries(initial).map(([path, value]) => [path, { value, sha: `blob-${path}` }]));
  const calls = [];
  let head = options.head ?? 'commit-1';
  let ambiguousNextMutation = false;
  const request = async ({ method, path, body }) => {
    calls.push({ method, path, body });
    if (method === 'GET' && path.includes('/git/ref/heads/')) return { object: { sha: head } };
    const match = path.match(/\/contents\/(.*?)(?:\?ref=.*)?$/);
    const filePath = match ? decodeURIComponent(match[1]) : null;
    if (method === 'GET') {
      const file = files.get(filePath);
      if (!file) throw missing();
      return { content: json(file.value), encoding: 'base64', sha: file.sha };
    }
    if (method === 'PUT') {
      const current = files.get(filePath);
      if (body.sha && (!current || current.sha !== body.sha)) throw Object.assign(new Error('stale'), { status: 409 });
      if (!body.sha && current) throw Object.assign(new Error('exists'), { status: 422 });
      const value = JSON.parse(Buffer.from(body.content, 'base64').toString('utf8'));
      files.set(filePath, { value, sha: `blob-${calls.length}` });
      if (ambiguousNextMutation) { ambiguousNextMutation = false; throw new Error('network outcome unknown'); }
      return { content: { sha: files.get(filePath).sha } };
    }
    throw new Error('unsupported');
  };
  return { request, calls, files, setHead: (value) => { head = value; }, makeNextMutationAmbiguous: () => { ambiguousNextMutation = true; } };
}
const clientFor = (fake) => createGitHubContentsRuntimeClient({ repositoryFullName: 'org/repo', branch: 'main', request: fake.request });

test('import and factory are zero-I/O and validate configuration', () => {
  let calls = 0;
  const client = createGitHubContentsRuntimeClient({ repositoryFullName: 'org/repo', branch: 'main', request: async () => { calls += 1; } });
  assert.equal(calls, 0);
  assert.throws(() => createGitHubContentsRuntimeClient({ repositoryFullName: 'org/repo', branch: 'main' }), /injected request/);
  assert.equal(typeof client.createJson, 'function');
});

test('getBranchHead returns exact current branch SHA', async () => {
  const fake = fakeRepository();
  assert.deepEqual(await clientFor(fake).getBranchHead(), { ref: 'commit-1', sha: 'commit-1' });
});

test('readJsonAtRef reads exact ref and returns blob SHA', async () => {
  const fake = fakeRepository({ 'state.json': { ok: true } });
  const result = await clientFor(fake).readJsonAtRef('state.json', 'immutable-ref');
  assert.deepEqual(result.value, { ok: true });
  assert.equal(result.blobSha, 'blob-state.json');
  assert.match(fake.calls[0].path, /ref=immutable-ref/);
});

test('readJsonCurrent captures one head and reads at that same ref', async () => {
  const fake = fakeRepository({ 'state.json': { n: 1 } });
  const result = await clientFor(fake).readJsonCurrent('state.json');
  assert.equal(result.ref, 'commit-1');
  assert.deepEqual(fake.calls.map((call) => call.method), ['GET', 'GET']);
  assert.match(fake.calls[1].path, /ref=commit-1/);
});

test('createJson absent path performs one mutation and succeeds', async () => {
  const fake = fakeRepository();
  const result = await clientFor(fake).createJson('new.json', { n: 1 });
  assert.equal(result.status, 'CREATED');
  assert.equal(fake.calls.filter((call) => call.method === 'PUT').length, 1);
});

test('exact-existing create reconciles idempotently without mutation', async () => {
  const fake = fakeRepository({ 'same.json': { n: 1 } });
  const result = await clientFor(fake).createJson('same.json', { n: 1 });
  assert.equal(result.status, 'IDEMPOTENT');
  assert.equal(fake.calls.filter((call) => call.method === 'PUT').length, 0);
});

test('conflicting-existing create fails closed', async () => {
  const fake = fakeRepository({ 'same.json': { n: 2 } });
  const result = await clientFor(fake).createJson('same.json', { n: 1 });
  assert.equal(result.status, 'CONFLICT');
  assert.equal(fake.calls.filter((call) => call.method === 'PUT').length, 0);
});

test('CAS update succeeds despite unrelated branch advancement', async () => {
  const fake = fakeRepository({ 'state.json': { n: 1 } });
  const client = clientFor(fake);
  fake.setHead('commit-2');
  const result = await client.updateJsonCas('state.json', 'blob-state.json', { n: 2 });
  assert.equal(result.status, 'UPDATED');
  assert.equal(fake.calls.filter((call) => call.method === 'PUT').length, 1);
  assert.equal(fake.calls.find((call) => call.method === 'PUT').body.sha, 'blob-state.json');
});

test('stale target SHA fails closed without blind retry', async () => {
  const fake = fakeRepository({ 'state.json': { n: 1 } });
  const result = await clientFor(fake).updateJsonCas('state.json', 'stale-sha', { n: 2 });
  assert.equal(result.status, 'CONFLICT');
  assert.equal(result.reasonCode, 'STALE_TARGET_SHA');
  assert.equal(fake.calls.filter((call) => call.method === 'PUT').length, 1);
});

test('ambiguous create reconciles once and never mutates twice', async () => {
  const fake = fakeRepository();
  fake.makeNextMutationAmbiguous();
  const result = await clientFor(fake).createJson('ambiguous.json', { n: 1 });
  assert.equal(result.status, 'IDEMPOTENT');
  assert.equal(fake.calls.filter((call) => call.method === 'PUT').length, 1);
});

test('ambiguous update reconciles once and never mutates twice', async () => {
  const fake = fakeRepository({ 'state.json': { n: 1 } });
  fake.makeNextMutationAmbiguous();
  const result = await clientFor(fake).updateJsonCas('state.json', 'blob-state.json', { n: 2 });
  assert.equal(result.status, 'IDEMPOTENT');
  assert.equal(fake.calls.filter((call) => call.method === 'PUT').length, 1);
});

test('errors do not leak credentials or authorization values', async () => {
  const secret = 'super-secret-token';
  const fake = { request: async () => { throw new Error(`Authorization: Bearer ${secret}`); } };
  const result = await clientFor(fake).createJson('state.json', { n: 1 });
  assert.equal(result.status, 'AMBIGUOUS');
  assert.equal(JSON.stringify(result).includes(secret), false);
  assert.equal(JSON.stringify(result).includes('Authorization'), false);
});
