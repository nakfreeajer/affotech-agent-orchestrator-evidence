import { createHash } from 'node:crypto';

export const DOCUMENTATION_TARGETS = Object.freeze(['docs/CURRENT_STATE.md', 'docs/PROJECT_HISTORY.md', 'docs/DECISIONS.md', 'docs/BUGS_AND_LESSONS.md', 'docs/ARCHITECTURE.md']);
const clone = (x) => x === undefined ? undefined : JSON.parse(JSON.stringify(x));
const object = (x) => x !== null && typeof x === 'object' && !Array.isArray(x);
const text = (x) => typeof x === 'string' && x.length > 0;
const sha256 = (x) => createHash('sha256').update(x, 'utf8').digest('hex');
const stable = (x) => { if (Array.isArray(x)) return `[${x.map(stable).join(',')}]`; if (object(x)) return `{${Object.keys(x).sort().map((k) => `${JSON.stringify(k)}:${stable(x[k])}`).join(',')}}`; return JSON.stringify(x); };
const fail = (reason) => Object.freeze({ valid: false, classification: 'CURATOR_DOCUMENT_RENDERER_INVALID', reasonCodes: [reason], mutationAuthorized: false, cursorAdvanceAuthorized: false });
const finish = (x) => `${x.replace(/\r\n/g, '\n').replace(/\n+$/g, '')}\n`;
const metadata = (input) => [`Project: ${input.projectId}`, `Projection input boundary: ${input.sourceRef}`, `Covered event range: ${input.eventRange.first}-${input.eventRange.last}`, 'Status: PENDING_ARCHITECT_SEMANTIC_ACCEPTANCE', 'Human-readable projection only; durable GitHub evidence and Architect decisions remain machine authority.'].join('\n');
const refs = (events) => events.map((e) => `- Sequence ${e.sequence}: ${e.eventType} — ${e.eventId} — ${e.detailsRef}`).join('\n');

function normalizeOverlay(input) {
  const raw = input.currentTruthOverlay ?? [];
  if (!Array.isArray(raw)) return fail('CURRENT_TRUTH_OVERLAY_INVALID');
  const normalized = [];
  for (const record of raw) {
    if (!object(record) || !text(record.decisionId) || record.classification !== 'ACCEPTED' || !text(record.semanticFactType) || !object(record.value) || !Array.isArray(record.evidenceRefs) || record.evidenceRefs.length === 0 || record.mirroredThroughSequence !== input.eventRange.last || record.overlayNotYetMirroredIntoEventLedger !== true) return fail('CURRENT_TRUTH_OVERLAY_AUTHORITY_INVALID');
    if (record.evidenceRefs.some((ref) => !text(ref))) return fail('CURRENT_TRUTH_OVERLAY_EVIDENCE_INVALID');
    const identity = `${record.semanticFactType}:${record.acceptedSourcePublicationId ?? ''}:${record.decisionId}`;
    normalized.push({ ...clone(record), overlayIdentity: identity });
  }
  normalized.sort((a, b) => a.overlayIdentity.localeCompare(b.overlayIdentity));
  const unique = [];
  for (const record of normalized) {
    const prior = unique.find((x) => x.semanticFactType === record.semanticFactType);
    if (prior && stable(prior) !== stable(record) && record.supersedes !== prior.overlayIdentity && prior.supersedes !== record.overlayIdentity) return fail('CURRENT_TRUTH_OVERLAY_CONTRADICTION');
    if (!prior || stable(prior) !== stable(record)) unique.push(record);
  }
  return unique;
}

function validateInput(input) {
  if (!object(input) || input.projectId !== 'affotech-agent-orchestrator' || !text(input.sourceRef) || !object(input.eventRange) || input.eventRange.first !== 1 || input.eventRange.last !== 15 || !Array.isArray(input.events) || input.events.length !== 15 || !object(input.acceptedSource) || !object(input.semantic) || !Array.isArray(input.causalChains)) return fail('REQUIRED_STRUCTURED_INPUT_MISSING');
  if (!DOCUMENTATION_TARGETS.every((target) => input.targets?.includes(target))) return fail('BOUND_TARGETS_INVALID');
  if (input.events.some((event, index) => event.sequence !== index + 1 || !text(event.eventId) || !text(event.eventType) || !text(event.detailsRef))) return fail('EVENT_PROVENANCE_INVALID');
  const s = input.semantic;
  if (s.orch000063 !== 'BLOCKED' || s.orch000064 !== 'ACCEPTED_ROOT_CAUSE_NOT_SOURCE' || s.orch000065 !== 'CURRENT_ACCEPTED_SOURCE' || s.orch000066 !== 'ACCEPTED_RECOVERY' || s.cursor !== 'NOT_CONSUMED') return fail('SEMANTIC_TRUTH_INPUT_INVALID');
  if (!text(input.acceptedSource.publicationId) || input.acceptedSource.files !== 95 || input.acceptedSource.fullTests !== '693/0/0' || !text(input.acceptedSource.manifestSha256) || !text(input.acceptedSource.archiveSha256)) return fail('ACCEPTED_SOURCE_INPUT_INVALID');
  return normalizeOverlay(input);
}

const overlayFact = (overlay, type) => overlay.find((fact) => fact.semanticFactType === type);
function renderCurrentState(input, overlay) {
  const source = overlayFact(overlay, 'ACCEPTED_SOURCE_BASELINE')?.value ?? input.acceptedSource;
  const overlayLines = overlay.length ? ['', '## Newer accepted current-truth overlay', `- These facts are newer durable Architect-accepted evidence and are not yet mirrored into the canonical event ledger through sequence ${input.eventRange.last}.`, ...overlay.map((fact) => `- ${fact.semanticFactType}: ${stable(fact.value)}; authority ${fact.decisionId}; evidence ${fact.evidenceRefs.join(', ')}.`)] : [];
  return finish([metadata(input), '', '# Current State', '', '## Accepted truth', '', '- Durable GitHub evidence and the chronological project-event ledger are reconstructable project memory.', `- The canonical event ledger remains coherent through sequence ${input.eventRange.last} at the frozen boundary.`, `- ${source.publicationId} is the latest accepted source baseline: ${source.files} files; full tests ${source.fullTests}.`, `- Accepted source manifest SHA-256: ${source.manifestSha256 ?? input.acceptedSource.manifestSha256}.`, `- Accepted source archive SHA-256: ${source.archiveSha256 ?? input.acceptedSource.archiveSha256}; archive size: ${source.archiveSize ?? input.acceptedSource.archiveSize} bytes.`, '- ORCH-000066 live event cutover recovery is Architect-accepted.', '- Curator remains optional and on-demand.', '- No live Curator cursor has consumed events.', '- No AFFOTECH integration or access is authorized by this projection.', ...overlayLines, '', '## Historical boundary', '', '- ORCH-000063 remains blocked historical evidence.', '- ORCH-000064 is accepted root-cause analysis, not an accepted source.'].join('\n'));
}
function renderHistory(input) { return finish([metadata(input), '', '# Project History', '', ...input.causalChains.map((chain) => `## ${chain.label}\n\n${chain.summary}\n\n${refs(input.events.filter((e) => chain.sequences.includes(e.sequence)))}`), '', 'Post-ledger overlay evidence is not rewritten into canonical event history.', ''].join('\n')); }
function renderDecisions(input) { const selected = input.events.filter((e) => [1, 5, 8, 11, 15].includes(e.sequence)); return finish([metadata(input), '', '# Architect Decisions', '', ...selected.map((e) => `## Sequence ${e.sequence}: ${e.eventType}\n\n- Identity: ${e.producerEventKey}\n- Classification: ${input.decisionClassifications[String(e.sequence)]}\n- Evidence: ${e.detailsRef}\n- Event: ${e.eventId}`), '', 'Machine decision records remain authoritative. Sequence 5 BLOCKED remains explicitly visible.', ''].join('\n')); }
function renderLessons(input) { return finish([metadata(input), '', '# Bugs and Lessons', '', '## Accepted root causes', '', '- SOURCE_ACCEPTED identity collision: decisionId was selected before acceptedSourcePublicationId.', '- Stored-record self-hash validation defect: validateStored hashed a record containing recordSha256.', '', '## Accepted countermeasures', '', '- SOURCE_ACCEPTED uses a distinct deterministic identity binding.', '- Stored-record validation excludes recordSha256 from its canonical self-hash.', '', '## Fail-closed lessons', '', '- Do not blindly retry after an ambiguous mutation.', '- Reconcile read-only first.', '- Preserve a valid canonical prefix.', '', `Evidence: ${input.events.find((e) => e.sequence === 7).detailsRef}; ${input.events.find((e) => e.sequence === 10).detailsRef}.`, ''].join('\n')); }
function renderArchitecture(input) { return finish([metadata(input), '', '# Architecture', '', '- Durable detailed evidence remains machine authority.', '- The project-event ledger is a chronological projection and index over that evidence.', '- First-hand producer ownership and deterministic producerEventKey identity provide event integrity and idempotency.', '- Immutable event records and a compare-and-swap index preserve the canonical chain.', '- Curator is an optional, on-demand human-readable documentation projection.', '- A Curator cursor can advance only after documentation preservation/readback and Architect semantic acceptance.', `- The accepted event-ledger state ends at sequence ${input.eventRange.last}; newer accepted overlay facts remain outside that ledger until separately mirrored.`, '', 'This does not claim continuous automatic Curator operation or a live cursor.', ''].join('\n')); }

export function renderDocumentationProjection(input = {}) {
  const checked = validateInput(input); if (!Array.isArray(checked)) return checked;
  const contents = [renderCurrentState, renderHistory, renderDecisions, renderLessons, renderArchitecture].map((render) => render(input, checked));
  const documents = Object.fromEntries(DOCUMENTATION_TARGETS.map((target, index) => [target, Object.freeze({ path: target, content: contents[index], sha256: sha256(contents[index]) })]));
  const digest = sha256(stable(Object.fromEntries(DOCUMENTATION_TARGETS.map((target) => [target, documents[target].sha256]))));
  return Object.freeze({ valid: true, classification: 'CURATOR_DOCUMENTATION_PROJECTION_RENDERED', projectId: input.projectId, sourceRef: input.sourceRef, eventRange: clone(input.eventRange), documents: Object.freeze(documents), documentPaths: Object.freeze([...DOCUMENTATION_TARGETS]), projectionDigest: digest, overlay: Object.freeze(clone(checked)), cursorAdvanceAuthorized: false, mutationAuthorized: false, retryAuthorized: false });
}

export const curatorDocumentRenderer = Object.freeze({ DOCUMENTATION_TARGETS, renderDocumentationProjection });
