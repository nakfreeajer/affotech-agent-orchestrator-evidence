import test from 'node:test';
import assert from 'node:assert/strict';
import { createCodexDirectTransport, directCodexInvocationId, canonicalCodexLocator } from '../src/host/codex-direct-transport.js';
import { createGitHubRuntimePorts } from '../src/host/github-runtime-ports.js';

const dispatch = (overrides = {}) => ({ messageId: 'ORCH-000201', dispatchId: 'DISPATCH-000201', targetRole: 'executor', expectedAcceptedSourcePublicationId: 'GH-PUB-165-WORKER-DELIVERY-LEGACY-LINEAGE-HYDRATION-REPAIR-READY-000001', ...overrides });
function fakeClient(seed = {}) {
  const records = new Map(Object.entries(seed));
  const calls = [];
  const notFound = () => { const e = new Error('NOT_FOUND'); e.code = 'NOT_FOUND'; throw e; };
  return {
    calls, records,
    async getBranchHead() { calls.push(['head']); return { ref: 'REF' }; },
    async readJsonAtRef(path) { return records.has(path) ? { value: records.get(path), blobSha: `sha-${path}` } : notFound(); },
    async updateJsonCas(path, expectedSha, value) { calls.push(['cas', path]); records.set(path, structuredClone(value)); return { status: 'UPDATED' }; },
    async readJsonCurrent(path) { calls.push(['read', path]); return records.has(path) ? { value: records.get(path), blobSha: `sha-${path}` } : notFound(); },
    async createJson(path, value) { calls.push(['create', path, value]); if (records.has(path)) return JSON.stringify(records.get(path)) === JSON.stringify(value) ? { status: 'IDEMPOTENT' } : { status: 'CONFLICT' }; records.set(path, structuredClone(value)); return { status: 'CREATED' }; }
  };
}
function make(options = {}) {
  const client = options.client ?? fakeClient();
  const spawned = [];
  const transport = createCodexDirectTransport({ client, repositoryFullName: 'nakfreeajer/affotech-agent-orchestrator-evidence', projectId: 'affotech-agent-orchestrator', workingDirectory: 'C:\\sandbox', timeoutMs: 1000, spawnChild: async (command) => { spawned.push(command); return { childStarted: true, exitCode: 0, timedOut: false, terminationAttemptCount: 0 }; }, observeTerminal: async () => ({ messageId: 'ORCH-000201', dispatchId: 'DISPATCH-000201', publicationId: 'PUB-201', requiresArchitectDecision: true }), ...options });
  return { client, spawned, transport };
}

test('DIRECT_CODEX_IDENTITY_DETERMINISTIC_AND_NOT_WORKER_DELIVERY_NAMESPACE', () => {
  assert.equal(directCodexInvocationId('DISPATCH-000201'), 'CODEX-DIRECT-INVOCATION-EXECUTOR-DISPATCH-000201');
  assert.notEqual(directCodexInvocationId('DISPATCH-000201'), directCodexInvocationId('DISPATCH-000202'));
  assert.equal(directCodexInvocationId('DISPATCH-000201').includes('WORKER-DELIVERY'), false);
});
test('EXACT_GITHUB_DISPATCH_LOCATOR_BOUND', () => assert.equal(canonicalCodexLocator('nakfreeajer/affotech-agent-orchestrator-evidence', 'DISPATCH-000201'), 'execute github dispatch nakfreeajer/affotech-agent-orchestrator-evidence DISPATCH-000201'));
test('DURABLE_INTENT_READBACK_PRECEDES_CHILD_SPAWN', async () => { const x = make(); const out = await x.transport.send({ dispatch: dispatch() }); assert.equal(out.status, 'SENT'); assert.equal(x.spawned.length, 1); assert.equal(x.client.calls.findIndex(c => c[0] === 'create'), 2); assert.equal(x.client.calls.findIndex(c => c[0] === 'read' && c[1].endsWith('/intent.json')) < x.client.calls.findIndex(c => c[0] === 'create' && c[1].endsWith('/result.json')), true); });
test('FRESH_INVOCATION_SPAWNS_EXACTLY_ONCE_WITH_EXPECTED_CONTROLS', async () => { const x = make(); await x.transport.send({ dispatch: dispatch() }); assert.equal(x.spawned.length, 1); assert.deepEqual(x.spawned[0].args, ['exec', '--ephemeral', '--sandbox', 'read-only', '-C', 'C:\\sandbox', 'execute github dispatch nakfreeajer/affotech-agent-orchestrator-evidence DISPATCH-000201']); });
test('DURABLE_RESULT_AND_EXACT_TERMINAL_OBSERVATION_REQUIRED_FOR_SUCCESS', async () => { const x = make({ observeTerminal: async () => ({ messageId: 'ORCH-000201', dispatchId: 'DISPATCH-000201', publicationId: 'PUB-201', requiresArchitectDecision: true }) }); const out = await x.transport.send({ dispatch: dispatch() }); assert.equal(out.outcome, 'TERMINAL_OBSERVED'); assert.equal(out.terminalObserved, true); assert.equal(x.client.records.get(out.resultPath).terminalPublicationId, 'PUB-201'); });
test('COMPLETED_DUPLICATE_SECOND_SPAWN_COUNT_ZERO', async () => { const x = make(); const first = await x.transport.send({ dispatch: dispatch() }); const second = await x.transport.send({ dispatch: dispatch() }); assert.equal(first.status, 'SENT'); assert.equal(second.duplicateSuppressed, true); assert.equal(second.childInvocationCount, 0); assert.equal(x.spawned.length, 1); });
test('INTENT_WITHOUT_RESULT_REQUIRES_RECONCILIATION_AND_ZERO_SPAWN', async () => { const x = make(); await x.transport.send({ dispatch: dispatch() }); x.client.records.delete(`${x.transport.paths('CODEX-DIRECT-INVOCATION-EXECUTOR-DISPATCH-000201').result}`); const out = await x.transport.send({ dispatch: dispatch() }); assert.equal(out.reasonCode, 'RECONCILIATION_REQUIRED'); assert.equal(x.spawned.length, 1); });
test('INTENT_OR_RESULT_LINEAGE_MISMATCH_FAILS_CLOSED_ZERO_SPAWN', async () => { const x = make(); const id = x.transport.paths('CODEX-DIRECT-INVOCATION-EXECUTOR-DISPATCH-000201'); x.client.records.set(id.intent, { invocationId: 'WRONG', messageId: 'WRONG', dispatchId: 'WRONG' }); const out = await x.transport.send({ dispatch: dispatch() }); assert.equal(out.reasonCode, 'RECONCILIATION_REQUIRED'); assert.equal(x.spawned.length, 0); });
test('AUTH_FAILURE_DISTINCT_AND_NO_RETRY', async () => { const x = make({ spawnChild: async () => ({ childStarted: true, exitCode: null, failureClass: 'AUTH_FAILED' }) }); const out = await x.transport.send({ dispatch: dispatch() }); assert.equal(out.outcome, 'AUTH_FAILED'); assert.equal(out.retryAuthorized, false); });
test('CHILD_NONZERO_EXIT_DISTINCT_AND_NO_RETRY', async () => { const x = make({ spawnChild: async () => ({ childStarted: true, exitCode: 7 }) }); const out = await x.transport.send({ dispatch: dispatch() }); assert.equal(out.outcome, 'CHILD_EXIT_NONZERO'); assert.equal(out.retryAttempted, false); });
test('CHILD_TIMEOUT_TERMINATES_EXACT_CHILD_AT_MOST_ONCE_AND_NO_RETRY', async () => { const x = make({ spawnChild: async () => ({ childStarted: true, exitCode: null, timedOut: true, terminationAttemptCount: 1 }) }); const out = await x.transport.send({ dispatch: dispatch() }); assert.equal(out.outcome, 'CHILD_TIMEOUT'); assert.equal(out.terminationAttemptCount, 1); });
test('CHILD_PROCESS_ERROR_DISTINCT_AND_NO_RETRY', async () => { const x = make({ spawnChild: async () => { throw Object.assign(new Error('boom'), { code: 'ENOENT' }); } }); const out = await x.transport.send({ dispatch: dispatch() }); assert.equal(out.outcome, 'CHILD_PROCESS_ERROR'); });
test('TERMINAL_NOT_OBSERVED_IS_AMBIGUOUS_AND_NO_RETRY', async () => { const x = make({ observeTerminal: async () => null }); const out = await x.transport.send({ dispatch: dispatch() }); assert.equal(out.outcome, 'TERMINAL_NOT_OBSERVED'); assert.equal(out.status, 'AMBIGUOUS'); });
test('TERMINAL_LINEAGE_MISMATCH_FAILS_CLOSED', async () => { const x = make({ observeTerminal: async () => ({ messageId: 'WRONG', dispatchId: 'DISPATCH-000201', publicationId: 'PUB', requiresArchitectDecision: true }) }); const out = await x.transport.send({ dispatch: dispatch() }); assert.equal(out.outcome, 'TERMINAL_LINEAGE_MISMATCH'); });
test('SANDBOX_DEFAULTS_READ_ONLY_AND_AUTHORIZED_MODE_PROPAGATES_EXPLICITLY', async () => { const x = make(); assert.equal(x.transport.sandbox, 'read-only'); const y = make({ sandbox: 'workspace-write' }); await y.transport.send({ dispatch: dispatch({ dispatchId: 'DISPATCH-000202' }) }); assert.equal(y.spawned[0].args[3], 'workspace-write'); });
test('PERSISTENT_HOST_DIRECT_CODEX_ROUTE_DOES_NOT_REQUIRE_BROWSERRELAY', () => { const direct = { send: async () => ({ status: 'SENT' }) }; const ports = createGitHubRuntimePorts({ client: fakeClient(), repositoryFullName: 'repo', branch: 'main', projectId: 'affotech-agent-orchestrator', hostInstanceId: 'HOST-INSTANCE-TEST', hostGenerationId: 'HOST-GEN-TEST', directCodexTransport: direct }); assert.equal(ports.directCodexMode, true); assert.equal(typeof ports.sendWorkerDelivery, 'function'); });
