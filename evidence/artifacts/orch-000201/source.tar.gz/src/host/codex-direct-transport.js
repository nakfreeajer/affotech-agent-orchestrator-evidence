import crypto from 'node:crypto';

const object = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
const clone = (value) => value === undefined ? undefined : JSON.parse(JSON.stringify(value));
const serialized = (value) => `${JSON.stringify(value)}\n`;
const sha256 = (value) => crypto.createHash('sha256').update(value, 'utf8').digest('hex');
const status = (value) => value?.status ?? value?.outcome ?? value?.state ?? null;
const missing = (error) => error?.code === 'NOT_FOUND' || error?.status === 404 || error?.statusCode === 404 || error?.absent === true;
const failure = (reasonCode, extra = {}) => ({ status: 'FAILED', outcome: reasonCode, reasonCode, childStarted: false, childInvocationCount: 0, timedOut: false, terminationAttemptCount: 0, retryAttempted: false, retryAuthorized: false, ...extra });

export function directCodexInvocationId(dispatchId, workerRole = 'executor') {
  if (typeof dispatchId !== 'string' || !dispatchId || typeof workerRole !== 'string' || !workerRole) throw new TypeError('dispatchId and workerRole are required');
  return `CODEX-DIRECT-INVOCATION-${workerRole.toUpperCase()}-${dispatchId}`;
}

export function canonicalCodexLocator(repositoryFullName, dispatchId) {
  if (typeof repositoryFullName !== 'string' || !repositoryFullName || typeof dispatchId !== 'string' || !dispatchId) throw new TypeError('repositoryFullName and dispatchId are required');
  return `execute github dispatch ${repositoryFullName} ${dispatchId}`;
}

function validateOptions(options) {
  if (!object(options) || !object(options.client) || typeof options.client.readJsonCurrent !== 'function' || typeof options.client.createJson !== 'function' || typeof options.spawnChild !== 'function' || typeof options.observeTerminal !== 'function') throw new TypeError('client, spawnChild, and observeTerminal are required');
  if (typeof options.repositoryFullName !== 'string' || typeof options.workingDirectory !== 'string' || typeof options.projectId !== 'string') throw new TypeError('repositoryFullName, workingDirectory, and projectId are required');
  if (options.sandbox !== undefined && !['read-only', 'workspace-write', 'danger-full-access'].includes(options.sandbox)) throw new TypeError('sandbox mode is invalid');
}

export function createCodexDirectTransport(options = {}) {
  validateOptions(options);
  const { client, repositoryFullName, workingDirectory, projectId } = options;
  const sandbox = options.sandbox ?? 'read-only';
  const timeoutMs = Number.isInteger(options.timeoutMs) && options.timeoutMs > 0 ? options.timeoutMs : 180000;
  const outputPath = options.outputPath ?? null;
  const read = async (path) => client.readJsonCurrent(path);
  const readMaybe = async (path) => { try { const value = await read(path); return value?.value ?? value; } catch (error) { if (missing(error)) return null; throw error; } };
  const paths = (invocationId) => ({
    intent: `evidence/codex-direct-invocations/executor/${invocationId}/intent.json`,
    result: `evidence/codex-direct-invocations/executor/${invocationId}/result.json`
  });

  async function send(input = {}) {
    const dispatch = input.dispatch ?? input.decision?.dispatch ?? input.snapshot?.lifecycleInput?.currentDispatch;
    if (!object(dispatch) || dispatch.targetRole !== 'executor' || typeof dispatch.dispatchId !== 'string' || typeof dispatch.messageId !== 'string') return failure('DISPATCH_INVALID');
    const invocationId = directCodexInvocationId(dispatch.dispatchId, 'executor');
    const locator = canonicalCodexLocator(repositoryFullName, dispatch.dispatchId);
    const p = paths(invocationId);
    let existingIntent; let existingResult;
    try { existingIntent = await readMaybe(p.intent); existingResult = await readMaybe(p.result); } catch { return failure('RECONCILIATION_REQUIRED', { reconciliationRequired: true }); }
    if (existingResult) {
      if (existingResult.invocationId !== invocationId || existingResult.messageId !== dispatch.messageId || existingResult.dispatchId !== dispatch.dispatchId) return failure('RESULT_LINEAGE_CONFLICT', { reconciliationRequired: true });
      return { ...clone(existingResult), status: 'SENT', outcome: existingResult.outcome ?? 'TERMINAL_OBSERVED', childStarted: false, childInvocationCount: 0, duplicateSuppressed: true };
    }
    if (existingIntent) return failure('RECONCILIATION_REQUIRED', { reconciliationRequired: true, invocationId, intentPath: p.intent, childInvocationCount: 0 });
    const intent = {
      schemaVersion: '1.0', recordType: 'CODEX_DIRECT_INVOCATION_INTENT', invocationId,
      workerRole: 'executor', projectId, messageId: dispatch.messageId, dispatchId: dispatch.dispatchId,
      locator, locatorSha256: sha256(locator), acceptedSourcePublicationId: dispatch.expectedAcceptedSourcePublicationId ?? dispatch.acceptedSourcePublicationId ?? null,
      workingDirectory, sandbox, ephemeral: true, maxChildInvocationCount: 1, timeoutMs, noRetry: true, state: 'ARMED'
    };
    let created;
    try { created = await client.createJson(p.intent, intent); } catch { return failure('INTENT_AMBIGUOUS', { reconciliationRequired: true, invocationId, intentPath: p.intent }); }
    if (!['CREATED', 'IDEMPOTENT', 'OK'].includes(status(created))) return failure('INTENT_AMBIGUOUS', { reconciliationRequired: true, invocationId, intentPath: p.intent });
    let intentReadback;
    try { intentReadback = await read(p.intent); } catch { return failure('INTENT_AMBIGUOUS', { reconciliationRequired: true, invocationId, intentPath: p.intent }); }
    const intentValue = intentReadback.value ?? intentReadback;
    if (JSON.stringify(intentValue) !== JSON.stringify(intent)) return failure('INTENT_AMBIGUOUS', { reconciliationRequired: true, invocationId, intentPath: p.intent });
    const intentSha256 = sha256(serialized(intent));
    const command = {
      executable: options.executable ?? 'codex', args: ['exec', '--ephemeral', '--sandbox', sandbox, '-C', workingDirectory, ...(outputPath ? ['-o', outputPath] : []), locator],
      cwd: workingDirectory, timeoutMs, sandbox, ephemeral: true, locator
    };
    let processResult;
    try { processResult = await options.spawnChild(command); } catch (error) { processResult = { outcome: 'CHILD_PROCESS_ERROR', errorCode: error?.code ?? 'CHILD_PROCESS_ERROR', exitCode: null, childStarted: false }; }
    processResult = object(processResult) ? processResult : {};
    const childStarted = processResult.childStarted !== false;
    const childInvocationCount = childStarted ? 1 : 0;
    const timedOut = processResult.timedOut === true;
    const terminationAttemptCount = Number.isInteger(processResult.terminationAttemptCount) ? processResult.terminationAttemptCount : 0;
    let terminal = null;
    let terminalObserved = false;
    let terminalPublicationId = null;
    let outcome = 'CHILD_PROCESS_ERROR';
    let failureClass = processResult.failureClass ?? processResult.outcome ?? null;
    if (!childStarted) failureClass = failureClass ?? 'CHILD_PROCESS_ERROR';
    else if (timedOut) failureClass = 'CHILD_TIMEOUT';
    else if (processResult.exitCode !== 0) failureClass = failureClass ?? 'CHILD_EXIT_NONZERO';
    else {
      try { terminal = await options.observeTerminal({ messageId: dispatch.messageId, dispatchId: dispatch.dispatchId, bounded: true }); }
      catch { terminal = null; }
      if (terminal?.messageId !== dispatch.messageId || terminal?.dispatchId !== dispatch.dispatchId) failureClass = terminal ? 'TERMINAL_LINEAGE_MISMATCH' : 'TERMINAL_NOT_OBSERVED';
      else if (terminal?.requiresArchitectDecision !== true || typeof terminal?.publicationId !== 'string' || !terminal.publicationId) failureClass = 'TERMINAL_NOT_OBSERVED';
      else { terminalObserved = true; terminalPublicationId = terminal.publicationId; outcome = 'TERMINAL_OBSERVED'; }
    }
    const result = {
      schemaVersion: '1.0', recordType: 'CODEX_DIRECT_INVOCATION_RESULT', invocationId, intentPath: p.intent,
      intentSha256, messageId: dispatch.messageId, dispatchId: dispatch.dispatchId, childStarted, childInvocationCount,
      timedOut, terminationAttemptCount, exitCode: processResult.exitCode ?? null, failureClass: terminalObserved ? null : failureClass,
      terminalObserved, terminalPublicationId, retryAttempted: false, retryAuthorized: false,
      outcome: terminalObserved ? outcome : failureClass, completedAt: options.nowMs ?? Date.now()
    };
    let resultWrite;
    try { resultWrite = await client.createJson(p.result, result); } catch { return failure('RESULT_AMBIGUOUS', { reconciliationRequired: true, invocationId, intentPath: p.intent, resultPath: p.result, childStarted, childInvocationCount }); }
    if (!['CREATED', 'IDEMPOTENT', 'OK'].includes(status(resultWrite))) return failure('RESULT_AMBIGUOUS', { reconciliationRequired: true, invocationId, resultPath: p.result, childStarted, childInvocationCount });
    let readback;
    try { readback = await read(p.result); } catch { return failure('RESULT_AMBIGUOUS', { reconciliationRequired: true, invocationId, resultPath: p.result, childStarted, childInvocationCount }); }
    const durableResult = readback.value ?? readback;
    if (JSON.stringify(durableResult) !== JSON.stringify(result)) return failure('RESULT_LINEAGE_CONFLICT', { reconciliationRequired: true, invocationId, resultPath: p.result, childStarted, childInvocationCount });
    return { ...clone(result), status: terminalObserved ? 'SENT' : 'AMBIGUOUS', durableResult: true, intentPath: p.intent, resultPath: p.result };
  }
  return Object.freeze({ send, paths, repositoryFullName, projectId, workingDirectory, sandbox, timeoutMs, directCodexMode: true });
}
