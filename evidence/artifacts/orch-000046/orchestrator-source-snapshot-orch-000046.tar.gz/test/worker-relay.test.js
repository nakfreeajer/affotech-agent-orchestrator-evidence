import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createWorkerAuthority, createWorkerRegistration, createWorkerDeliveryIntent, createWorkerDeliveryResult, createWorkerDeliveryPointer, validateWorkerAuthority, validateWorkerRegistration, validateWorkerDeliveryIntent, validateWorkerDeliveryResult, validateWorkerDeliveryPointer, resolveWorkerRegistration, resolveWorkerPromptPayload, validateGithubDispatchLocator, createGithubDispatchLocator, confirmWorkerComposerSend, validateWorkerDeliveryBundle, classifyWorkerDelivery, reconcileWorkerDelivery, workerAuthorityPath, workerRegistrationPath, workerCurrentPointers, workerDeliveryPath, workerDeliveryIntentPath, workerDeliveryResultPath, workerCurrentDeliveryPointer, workerDeliveryPaths, GITHUB_DISPATCH_LOCATOR_PROTOCOL, resolveGithubDispatchLocator, evaluateDispatchWatcher, runAutomaticRelayCycle, validateArchitectReconciliationCompatibility, buildArchitectPreSendBoundary, validateArchitectPreSendBoundary, evaluateArchitectPreSendBoundary, evaluateArchitectPostSend } from '../src/browser-relay/worker-relay.js';
import { evaluateCorrelationEvidence } from '../src/protocol/compatibility-registry.js';

const prompt = 'ORCH synthetic canonical worker prompt\n';
const hash = (x) => crypto.createHash('sha256').update(x, 'utf8').digest('hex');
const fixture = (role = 'executor') => {
  const authority = createWorkerAuthority({ workerRole: role, authorityId: `AUTH-${role}`, generationId: 'GEN-1', missionId: 'MISSION-WORKER-RELAY', createdAt: 100 });
  const registration = createWorkerRegistration({ workerRole: role, registrationId: `REG-${role}`, authorityId: authority.authorityId, authoritySha256: authority.authoritySha256, generationId: authority.generationId, missionId: authority.missionId, conversationId: `CONV-${role}`, conversationUrl: `https://chatgpt.com/c/${role}`, relayPort: role === 'executor' ? 9331 : 9332, createdAt: 101 });
  const dispatch = { schemaVersion: '1.0', recordType: 'DISPATCH', dispatchState: 'READY', dispatchId: `DISPATCH-${role}`, messageId: `MSG-${role}`, targetRole: role, canonicalPromptPath: 'evidence/prompts/WORKER-001.md', canonicalPromptSha256: hash(prompt) };
  const pointers = { authorityPointer: { pointerKind: 'WORKER_AUTHORITY', workerRole: role, recordId: authority.authorityId, recordSha256: authority.authoritySha256 }, registrationPointer: { pointerKind: 'WORKER_REGISTRATION', workerRole: role, recordId: registration.registrationId, recordSha256: registration.registrationSha256 } };
  const intent = createWorkerDeliveryIntent({ deliveryId: `DELIVERY-${role}`, workerRole: role, dispatchId: dispatch.dispatchId, messageId: dispatch.messageId, canonicalPromptPath: dispatch.canonicalPromptPath, canonicalPromptSha256: dispatch.canonicalPromptSha256, authorityId: authority.authorityId, authoritySha256: authority.authoritySha256, registrationId: registration.registrationId, registrationSha256: registration.registrationSha256, conversationId: registration.conversationId, conversationUrl: registration.conversationUrl, relayPort: registration.relayPort, createdAt: 102 });
  return { authority, registration, dispatch, pointers, authorityPointer: pointers.authorityPointer, registrationPointer: pointers.registrationPointer, intent, prompt, promptBytes: prompt, missionId: authority.missionId, workerRole: role };
};

test('role-separated authority, registration, pointers, and immutable hashes are deterministic', () => { const a = fixture('executor'); const c = fixture('documentation_curator'); assert.notEqual(a.authority.authorityId, c.authority.authorityId); assert.equal(validateWorkerAuthority(a.authority).valid, true); assert.equal(validateWorkerRegistration(a.registration, { authority: a.authority }).valid, true); assert.deepEqual(workerCurrentPointers('executor'), { authorityPointer: 'evidence/current/worker/executor/LATEST_AUTHORITY.json', registrationPointer: 'evidence/current/worker/executor/LATEST_REGISTRATION.json' }); assert.notEqual(workerAuthorityPath('executor', 'AUTH-executor'), workerAuthorityPath('documentation_curator', 'AUTH-documentation_curator')); assert.ok(workerDeliveryPath('executor', 'DELIVERY-executor').includes('/executor/')); });
test('foreign role cannot use another role registration or pointer', () => { const x = fixture('executor'); assert.equal(resolveWorkerRegistration({ ...x, workerRole: 'documentation_curator' }).classification, 'FAIL_CLOSED'); const y = fixture('executor'); y.registration.workerRole = 'documentation_curator'; assert.equal(validateWorkerRegistration(y.registration, { authority: y.authority }).valid, false); });
test('canonical prompt bytes and dispatch hash are the only payload authority', () => { const x = fixture(); const resolved = resolveWorkerPromptPayload({ dispatch: x.dispatch, promptBytes: x.prompt, registeredWorkerRole: x.workerRole }); assert.equal(resolved.classification, 'READY'); assert.equal(resolved.promptBytes.toString('utf8'), x.prompt); assert.equal(resolved.payloadSource, 'CANONICAL_GITHUB_PROMPT'); const tampered = resolveWorkerPromptPayload({ dispatch: x.dispatch, promptBytes: `${x.prompt}edited`, registeredWorkerRole: x.workerRole }); assert.equal(tampered.classification, 'FAIL_CLOSED'); });
test('role mismatch and noncanonical prompt path fail closed', () => { const x = fixture(); assert.equal(resolveWorkerPromptPayload({ dispatch: { ...x.dispatch, targetRole: 'documentation_curator' }, promptBytes: x.prompt, registeredWorkerRole: 'executor' }).classification, 'FAIL_CLOSED'); assert.equal(resolveWorkerPromptPayload({ dispatch: { ...x.dispatch, canonicalPromptPath: 'issue-comment-text' }, promptBytes: x.prompt, registeredWorkerRole: 'executor' }).classification, 'FAIL_CLOSED'); });
test('delivery intent is durable before send and is exactly one authorization boundary', () => { const x = fixture(); assert.equal(validateWorkerDeliveryIntent(x.intent).valid, true); assert.equal(x.intent.intendedSendCount, 1); const ready = validateWorkerDeliveryBundle({ ...x, result: undefined }); assert.equal(ready.classification, 'INTENT_ARMED'); assert.equal(ready.workerDispatchAuthorized, false); assert.equal(ready.reconciliationRequired, true); });
test('exact successful result is accepted once and response DOM is forbidden', () => { const x = fixture(); const result = createWorkerDeliveryResult({ deliveryId: x.intent.deliveryId, intentSha256: x.intent.intentSha256, workerRole: x.workerRole, outcome: 'SENT', attemptedSendCount: 1, confirmedSendCount: 1, browserDisconnected: true, resultRecordedAt: 103 }); assert.equal(validateWorkerDeliveryResult(result, x.intent).valid, true); const resolved = validateWorkerDeliveryBundle({ ...x, result }); assert.equal(resolved.classification, 'SENT'); assert.equal(result.responseDomRead, false); });
test('ambiguous outcome never retries and requires reconciliation', () => { const x = fixture(); const result = createWorkerDeliveryResult({ deliveryId: x.intent.deliveryId, intentSha256: x.intent.intentSha256, workerRole: x.workerRole, outcome: 'AMBIGUOUS', attemptedSendCount: 1, confirmedSendCount: 0, browserDisconnected: true, resultRecordedAt: 103 }); const resolved = validateWorkerDeliveryBundle({ ...x, result }); assert.equal(resolved.classification, 'RECONCILIATION_REQUIRED'); assert.equal(resolved.retryAuthorized, false); assert.equal(reconcileWorkerDelivery({ intent: x.intent, observation: 'UNKNOWN' }).classification, 'RECONCILIATION_REQUIRED'); });
test('failed-before-send remains non-authorizing and cannot be promoted by reconciliation', () => { const x = fixture(); const result = createWorkerDeliveryResult({ deliveryId: x.intent.deliveryId, intentSha256: x.intent.intentSha256, workerRole: x.workerRole, outcome: 'FAILED_BEFORE_SEND', attemptedSendCount: 0, confirmedSendCount: 0, browserDisconnected: false, resultRecordedAt: 103 }); assert.equal(classifyWorkerDelivery({ intent: x.intent, result }).classification, 'FAILED_BEFORE_SEND'); assert.equal(reconcileWorkerDelivery({ intent: x.intent, observation: 'NOT_SENT' }).retryAuthorized, false); });
test('duplicate or conflicting delivery identity fails closed', () => { const x = fixture(); const altered = { ...x.intent, canonicalPromptSha256: '0'.repeat(64) }; assert.equal(validateWorkerDeliveryIntent(altered).valid, false); const result = createWorkerDeliveryResult({ deliveryId: x.intent.deliveryId, intentSha256: '0'.repeat(64), workerRole: x.workerRole, outcome: 'SENT', attemptedSendCount: 1, confirmedSendCount: 1, browserDisconnected: false, resultRecordedAt: 103 }); assert.equal(validateWorkerDeliveryResult(result, x.intent).valid, false); });
test('all governed controls suppress worker delivery', () => { const x = fixture(); for (const state of ['PAUSED_BY_RONY', 'STOP', 'ABORT_CURRENT_WORKER', 'RECONCILIATION_REQUIRED', 'CIRCUIT_OPEN']) { const out = validateWorkerDeliveryBundle({ ...x, controlState: state }); assert.equal(out.classification, state); assert.equal(out.workerDispatchAuthorized, false); assert.equal(out.retryAuthorized, false); } });
test('invalid control is fail closed', () => { const x = fixture(); assert.equal(validateWorkerDeliveryBundle({ ...x, controlState: 'ISSUE_COMMENT' }).classification, 'FAIL_CLOSED'); });
test('mission, authority, registration, and dispatch bindings are strict', () => { const x = fixture(); assert.equal(validateWorkerDeliveryBundle({ ...x, missionId: 'OTHER' }).classification, 'FAIL_CLOSED'); const wrong = { ...x, dispatch: { ...x.dispatch, messageId: 'OTHER' } }; assert.equal(validateWorkerDeliveryBundle(wrong).classification, 'FAIL_CLOSED'); });
test('registration requires architect-owned current role pointers and exact hashes', () => { const x = fixture(); assert.equal(resolveWorkerRegistration({ ...x }).classification, 'READY'); assert.equal(resolveWorkerRegistration({ ...x, authorityPointer: { ...x.pointers.authorityPointer, recordSha256: '0'.repeat(64) } }).classification, 'FAIL_CLOSED'); assert.equal(resolveWorkerRegistration({ ...x, registrationPointer: { ...x.pointers.registrationPointer, workerRole: 'documentation_curator' } }).classification, 'FAIL_CLOSED'); });
test('stale consumed or superseded worker registration is rejected', () => { const x = fixture(); const consumed = { ...x.registration, consumed: true }; consumed.registrationSha256 = crypto.createHash('sha256').update(JSON.stringify({ ...consumed, registrationSha256: undefined }), 'utf8').digest('hex'); assert.equal(validateWorkerRegistration(consumed, { authority: x.authority }).valid, false); const superseded = { ...x.registration, supersededBy: 'REG-next' }; assert.equal(validateWorkerRegistration(superseded, { authority: x.authority }).valid, false); });
test('result counts and response-DOM access are constrained', () => { const x = fixture(); const bad = createWorkerDeliveryResult({ deliveryId: x.intent.deliveryId, intentSha256: x.intent.intentSha256, workerRole: x.workerRole, outcome: 'SENT', attemptedSendCount: 2, confirmedSendCount: 1, browserDisconnected: false, resultRecordedAt: 103 }); assert.equal(validateWorkerDeliveryResult(bad, x.intent).valid, false); const tampered = { ...bad, responseDomRead: true }; assert.equal(validateWorkerDeliveryResult(tampered, x.intent).valid, false); });
test('reconciliation observations are closed over and never authorize retry', () => { const x = fixture(); assert.equal(reconcileWorkerDelivery({ intent: x.intent, observation: 'ACCEPTED' }).classification, 'FAIL_CLOSED'); for (const observation of ['SENT', 'NOT_SENT']) assert.equal(reconcileWorkerDelivery({ intent: x.intent, observation }).retryAuthorized, false); });
test('no live worker registrations or sends are performed by the contract layer', () => { const x = fixture('documentation_curator'); const out = validateWorkerDeliveryBundle({ ...x }); assert.equal(out.classification, 'INTENT_ARMED'); assert.equal(out.workerDispatchAuthorized, false); assert.equal(out.sendPayload.toString(), prompt); });

test('delivery intent, result, and role-scoped current pointer paths are deterministic', () => {
  const x = fixture('executor');
  assert.equal(workerDeliveryIntentPath('executor', x.intent.deliveryId), 'evidence/worker-deliveries/executor/DELIVERY-executor/intent.json');
  assert.equal(workerDeliveryResultPath('executor', x.intent.deliveryId), 'evidence/worker-deliveries/executor/DELIVERY-executor/result.json');
  assert.equal(workerCurrentDeliveryPointer('executor'), 'evidence/current/worker/executor/LATEST_DELIVERY.json');
  assert.deepEqual(workerDeliveryPaths('documentation_curator', 'D'), {
    deliveryDirectory: 'evidence/worker-deliveries/documentation_curator/D',
    intentPath: 'evidence/worker-deliveries/documentation_curator/D/intent.json',
    resultPath: 'evidence/worker-deliveries/documentation_curator/D/result.json',
    currentPointer: 'evidence/current/worker/documentation_curator/LATEST_DELIVERY.json'
  });
  assert.notEqual(workerCurrentDeliveryPointer('executor'), workerCurrentDeliveryPointer('documentation_curator'));
});

test('armed delivery pointer validates without a result and unresolved state cannot retry', () => {
  const x = fixture();
  const pointer = createWorkerDeliveryPointer({ workerRole: x.workerRole, deliveryId: x.intent.deliveryId, intent: x.intent });
  assert.equal(pointer.state, 'ARMED');
  assert.equal(validateWorkerDeliveryPointer(pointer, { intent: x.intent }).valid, true);
  assert.equal(classifyWorkerDelivery({ intent: x.intent }).classification, 'INTENT_ARMED');
  assert.equal(classifyWorkerDelivery({ intent: x.intent }).retryAuthorized, false);
});

test('terminal delivery pointers bind exact result lifecycle and hashes', () => {
  const x = fixture();
  const result = createWorkerDeliveryResult({ deliveryId: x.intent.deliveryId, intentSha256: x.intent.intentSha256, workerRole: x.workerRole, outcome: 'SENT', attemptedSendCount: 1, confirmedSendCount: 1, browserDisconnected: true, resultRecordedAt: 103 });
  const pointer = createWorkerDeliveryPointer({ workerRole: x.workerRole, deliveryId: x.intent.deliveryId, intent: x.intent, result });
  assert.equal(pointer.state, 'SENT');
  assert.equal(validateWorkerDeliveryPointer(pointer, { intent: x.intent, result }).valid, true);
  assert.equal(validateWorkerDeliveryPointer({ ...pointer, resultPath: `${pointer.resultPath}/other` }, { intent: x.intent, result }).valid, false);
  assert.equal(validateWorkerDeliveryPointer({ ...pointer, state: 'FAILED_BEFORE_SEND' }, { intent: x.intent, result }).valid, false);
});

test('executor and documentation curator delivery pointers cannot alias', () => {
  const e = fixture('executor');
  const c = fixture('documentation_curator');
  const ep = createWorkerDeliveryPointer({ workerRole: e.workerRole, deliveryId: e.intent.deliveryId, intent: e.intent });
  const cp = createWorkerDeliveryPointer({ workerRole: c.workerRole, deliveryId: c.intent.deliveryId, intent: c.intent });
  assert.notEqual(ep.intentPath, cp.intentPath);
  assert.equal(validateWorkerDeliveryPointer({ ...ep, workerRole: 'documentation_curator' }, { intent: e.intent }).valid, false);
});

test('ambiguous and unresolved armed delivery pointers remain non-authorizing', () => {
  const x = fixture();
  const result = createWorkerDeliveryResult({ deliveryId: x.intent.deliveryId, intentSha256: x.intent.intentSha256, workerRole: x.workerRole, outcome: 'AMBIGUOUS', attemptedSendCount: 1, confirmedSendCount: 0, browserDisconnected: true, resultRecordedAt: 103 });
  const pointer = createWorkerDeliveryPointer({ workerRole: x.workerRole, deliveryId: x.intent.deliveryId, intent: x.intent, result });
  assert.equal(validateWorkerDeliveryPointer(pointer, { intent: x.intent, result }).valid, true);
  assert.equal(classifyWorkerDelivery({ intent: x.intent, result }).classification, 'RECONCILIATION_REQUIRED');
  assert.equal(classifyWorkerDelivery({ intent: x.intent, result }).retryAuthorized, false);
});

test('GitHub dispatch locator is deterministic, ASCII, single-line, and bounded', () => {
  const locator = createGithubDispatchLocator({ dispatchId: 'DISPATCH-000031' });
  assert.equal(locator, 'execute github dispatch nakfreeajer/affotech-agent-orchestrator-evidence DISPATCH-000031');
  assert.equal(Buffer.byteLength(locator, 'utf8'), locator.length);
  assert.ok(Buffer.byteLength(locator, 'utf8') <= 160);
  assert.equal(locator.includes('\n'), false);
  assert.equal(/^[\x00-\x7F]+$/.test(locator), true);
});

test('locator payload binds exact SHA and byte count', () => {
  const x = fixture();
  const intent = createWorkerDeliveryIntent({ ...x.intent, deliveryPayloadKind: GITHUB_DISPATCH_LOCATOR_PROTOCOL });
  const expected = createGithubDispatchLocator({ dispatchId: x.dispatch.dispatchId });
  assert.equal(intent.deliveryPayloadText, expected);
  assert.equal(intent.deliveryPayloadByteCount, Buffer.byteLength(expected, 'utf8'));
  assert.equal(intent.deliveryPayloadSha256, hash(expected));
  assert.equal(validateWorkerDeliveryIntent(intent).valid, true);
});

test('changing dispatch ID changes locator and payload hash', () => {
  const a = createGithubDispatchLocator({ dispatchId: 'DISPATCH-A' });
  const b = createGithubDispatchLocator({ dispatchId: 'DISPATCH-B' });
  assert.notEqual(a, b);
  assert.notEqual(hash(a), hash(b));
});

test('wrong repository and wrong dispatch ID locators fail closed', () => {
  const x = fixture();
  assert.equal(createGithubDispatchLocator({ repository: 'evil/repo', dispatchId: x.dispatch.dispatchId }), null);
  const common = { immutableDispatch: x.dispatch, currentDispatch: x.dispatch, latestArchitectPrompt: { messageId: x.dispatch.messageId, promptPath: x.dispatch.canonicalPromptPath, promptSha256: x.dispatch.canonicalPromptSha256 }, architectDecision: { nextCanonicalMessageId: x.dispatch.messageId }, promptBytes: x.prompt, registeredWorkerRole: x.workerRole };
  assert.equal(validateGithubDispatchLocator({ ...common, locator: 'execute github dispatch evil/repo DISPATCH-executor' }).classification, 'FAIL_CLOSED');
  assert.equal(validateGithubDispatchLocator({ ...common, locator: 'execute github dispatch nakfreeajer/affotech-agent-orchestrator-evidence OTHER' }).classification, 'FAIL_CLOSED');
});

test('locator recipient validation requires immutable dispatch, current pointer, and prompt hash', () => {
  const x = fixture();
  const common = { locator: createGithubDispatchLocator({ dispatchId: x.dispatch.dispatchId }), immutableDispatch: x.dispatch, currentDispatch: x.dispatch, latestArchitectPrompt: { messageId: x.dispatch.messageId, promptPath: x.dispatch.canonicalPromptPath, promptSha256: x.dispatch.canonicalPromptSha256 }, architectDecision: { nextCanonicalMessageId: x.dispatch.messageId }, promptBytes: x.prompt, registeredWorkerRole: x.workerRole };
  assert.equal(validateGithubDispatchLocator(common).classification, 'READY');
  assert.equal(validateGithubDispatchLocator({ ...common, currentDispatch: { ...x.dispatch, canonicalPromptSha256: '0'.repeat(64) } }).classification, 'FAIL_CLOSED');
  assert.equal(validateGithubDispatchLocator({ ...common, promptBytes: `${x.prompt}tampered` }).classification, 'FAIL_CLOSED');
});

test('locator recipient target role mismatch fails closed', () => {
  const x = fixture();
  const locator = createGithubDispatchLocator({ dispatchId: x.dispatch.dispatchId });
  const out = validateGithubDispatchLocator({ locator, immutableDispatch: { ...x.dispatch, targetRole: 'documentation_curator' }, currentDispatch: x.dispatch, latestArchitectPrompt: { messageId: x.dispatch.messageId, promptPath: x.dispatch.canonicalPromptPath, promptSha256: x.dispatch.canonicalPromptSha256 }, architectDecision: { nextCanonicalMessageId: x.dispatch.messageId }, promptBytes: x.prompt, registeredWorkerRole: 'executor' });
  assert.equal(out.classification, 'FAIL_CLOSED');
});

test('locator cannot authorize without current Architect decision', () => {
  const x = fixture();
  const out = validateGithubDispatchLocator({ locator: createGithubDispatchLocator({ dispatchId: x.dispatch.dispatchId }), immutableDispatch: x.dispatch, currentDispatch: x.dispatch, latestArchitectPrompt: { messageId: x.dispatch.messageId, promptPath: x.dispatch.canonicalPromptPath, promptSha256: x.dispatch.canonicalPromptSha256 }, architectDecision: {}, promptBytes: x.prompt, registeredWorkerRole: x.workerRole });
  assert.equal(out.classification, 'FAIL_CLOSED');
});

test('locator mode sends only the compact payload while retaining canonical prompt binding', () => {
  const x = fixture();
  const intent = createWorkerDeliveryIntent({ ...x.intent, deliveryPayloadKind: GITHUB_DISPATCH_LOCATOR_PROTOCOL });
  const out = validateWorkerDeliveryBundle({ ...x, intent, result: undefined });
  assert.equal(out.classification, 'INTENT_ARMED');
  assert.equal(out.sendPayload.toString(), createGithubDispatchLocator({ dispatchId: x.dispatch.dispatchId }));
  assert.equal(out.canonicalPromptHash, x.dispatch.canonicalPromptSha256);
  assert.equal(out.payloadHash, intent.deliveryPayloadSha256);
});

test('invalid locator payload fields fail closed', () => {
  const x = fixture();
  const intent = createWorkerDeliveryIntent({ ...x.intent, deliveryPayloadKind: GITHUB_DISPATCH_LOCATOR_PROTOCOL, deliveryPayloadText: 'execute github dispatch wrong/repo D', deliveryPayloadSha256: hash('execute github dispatch wrong/repo D'), deliveryPayloadByteCount: 35 });
  assert.equal(validateWorkerDeliveryIntent(intent).valid, false);
});

test('structural composer clear confirms one SENT action without response DOM', () => {
  const out = confirmWorkerComposerSend({ sendActionCount: 1, composerText: '', browserDisconnected: true, responseDomRead: false });
  assert.equal(out.classification, 'SENT');
  assert.equal(out.attemptedSendCount, 1);
  assert.equal(out.confirmedSendCount, 1);
  assert.equal(out.responseDomRead, false);
});

test('non-empty composer after one action is ambiguous and cannot retry', () => {
  const out = confirmWorkerComposerSend({ sendActionCount: 1, composerText: 'still present', browserDisconnected: true, responseDomRead: false });
  assert.equal(out.classification, 'RECONCILIATION_REQUIRED');
  assert.equal(out.reconciliationRequired, true);
  assert.equal(out.retryAuthorized, false);
  assert.equal(out.confirmedSendCount, 0);
});

test('composer confirmation rejects multiple actions or response DOM access', () => {
  assert.equal(confirmWorkerComposerSend({ sendActionCount: 2, composerText: '', browserDisconnected: true }).classification, 'FAIL_CLOSED');
  assert.equal(confirmWorkerComposerSend({ sendActionCount: 1, composerText: '', browserDisconnected: true, responseDomRead: true }).classification, 'FAIL_CLOSED');
});

test('legacy full-prompt intent remains valid and is not converted to locator mode', () => {
  const x = fixture();
  assert.equal(validateWorkerDeliveryIntent(x.intent).valid, true);
  assert.equal(x.intent.deliveryPayloadKind, undefined);
  const out = validateWorkerDeliveryBundle({ ...x, result: undefined });
  assert.equal(out.sendPayload.toString(), x.prompt);
});

const nativeLocator = 'execute github dispatch nakfreeajer/affotech-agent-orchestrator-evidence DISPATCH-000036';
const nativePrompt = Buffer.from('native canonical prompt bytes\n', 'utf8');
const nativePromptSha = crypto.createHash('sha256').update(nativePrompt).digest('hex');
function nativeGit(cwd, ...args) { return execFileSync('git', ['-C', cwd, ...args], { encoding: 'utf8' }).trim(); }
function nativeFixture(overrides = {}) {
  const root = mkdtempSync(path.join(os.tmpdir(), 'worker-relay-native-'));
  const write = (p, value) => { const target = path.join(root, p); mkdirSync(path.dirname(target), { recursive: true }); writeFileSync(target, JSON.stringify(value)); };
  const accepted = { pointerKind: 'EXECUTOR_ACCEPTED', publicationId: 'GH-PUB-030-GITHUB-DISPATCH-LOCATOR-000001', accepted: true, requiresArchitectDecision: false };
  const dispatch = { schemaVersion: '1.0', evidenceProject: 'affotech-agent-orchestrator', recordType: 'DISPATCH', dispatchId: 'DISPATCH-000036', messageId: 'ORCH-000036', canonicalPromptPath: 'evidence/prompts/ORCH-000036.md', canonicalPromptSha256: nativePromptSha, targetRole: 'executor', dispatchState: 'MANUAL_TRIGGER_REQUIRED' };
  const latestDispatch = { pointerKind: 'DISPATCH', ...dispatch };
  const latestPrompt = { pointerKind: 'ARCHITECT_PROMPT', messageId: 'ORCH-000036', promptPath: dispatch.canonicalPromptPath, promptSha256: nativePromptSha, targetRole: 'executor' };
  const decision = { pointerKind: 'ARCHITECT_DECISION', decision: 'ACCEPTED', nextCanonicalMessageId: 'ORCH-000036', acceptedSourceAnchorUnchanged: true };
  write('evidence/dispatches/DISPATCH-000036/DISPATCH.json', { ...dispatch, ...overrides.dispatch });
  write('evidence/current/LATEST_DISPATCH.json', { ...latestDispatch, ...overrides.latestDispatch });
  write('evidence/current/LATEST_ARCHITECT_PROMPT.json', { ...latestPrompt, ...overrides.latestPrompt });
  write('evidence/current/LATEST_ARCHITECT_DECISION.json', { ...decision, ...overrides.decision });
  write('evidence/current/LATEST_EXECUTOR_ACCEPTED.json', { ...accepted, ...overrides.accepted });
  mkdirSync(path.join(root, 'evidence/prompts'), { recursive: true }); writeFileSync(path.join(root, 'evidence/prompts/ORCH-000036.md'), nativePrompt);
  nativeGit(root, 'init'); nativeGit(root, 'config', 'user.email', 'test@example.invalid'); nativeGit(root, 'config', 'user.name', 'Test'); nativeGit(root, 'add', '.'); nativeGit(root, 'commit', '-m', 'fixture'); nativeGit(root, 'branch', '-M', 'main');
  return root;
}
function nativeRun(root, extra = {}) { return resolveGithubDispatchLocator({ repoRoot: root, ref: 'main', locatorText: nativeLocator, workerRole: 'executor', ...extra }); }
function nativeRejects(root, extra = {}) { assert.throws(() => nativeRun(root, extra), /GITHUB_DISPATCH_LOCATOR_REJECTED/); }

test('native resolver returns exact prompt bytes from one captured Git ref', () => { const root = nativeFixture(); try { const result = nativeRun(root); assert.equal(result.dispatchId, 'DISPATCH-000036'); assert.deepEqual(result.canonicalPromptBytes, nativePrompt); assert.equal(result.canonicalPromptSha256, nativePromptSha); } finally { rmSync(root, { recursive: true, force: true }); } });
test('native resolver rejects malformed, wrong-repository, and wrong-role locators', () => { const root = nativeFixture(); try { nativeRejects(root, { locatorText: 'bad locator' }); nativeRejects(root, { locatorText: 'execute github dispatch wrong/repo DISPATCH-000036' }); nativeRejects(root, { workerRole: 'curator' }); } finally { rmSync(root, { recursive: true, force: true }); } });
test('native resolver rejects pointer, authorization, and prompt hash mismatches', () => { for (const overrides of [{ latestDispatch: { dispatchId: 'DISPATCH-000035' } }, { latestPrompt: { messageId: 'ORCH-000035' } }, { decision: { nextCanonicalMessageId: 'ORCH-000035' } }, { dispatch: { canonicalPromptSha256: '0'.repeat(64) } }]) { const root = nativeFixture(overrides); try { nativeRejects(root); } finally { rmSync(root, { recursive: true, force: true }); } } });
test('native resolver rejects missing Git objects without executing the prompt', () => { const root = nativeFixture(); try { rmSync(path.join(root, 'evidence/prompts/ORCH-000036.md')); nativeGit(root, 'add', '-u'); nativeGit(root, 'commit', '-m', 'remove prompt'); nativeRejects(root); } finally { rmSync(root, { recursive: true, force: true }); } });
test('native resolver uses bounded Git argv and disables shell execution', () => { const source = readFileSync(new URL('../src/browser-relay/worker-relay.js', import.meta.url), 'utf8'); assert.match(source, /execFileSync\('git', \['-C', repoRoot, 'show'/); assert.match(source, /shell: false/); assert.doesNotMatch(source, /shell:\s*true/); });
test('native resolver captures one commit ref before object reads', () => { const source = readFileSync(new URL('../src/browser-relay/worker-relay.js', import.meta.url), 'utf8'); assert.match(source, /rev-parse.*verify.*\^\{commit\}/s); });
test('native resolver does not use Base64 or place prompt bytes in argv', () => { const source = readFileSync(new URL('../src/browser-relay/worker-relay.js', import.meta.url), 'utf8'); assert.doesNotMatch(source, /base64/i); assert.doesNotMatch(source, /canonicalPromptBytes.*execFileSync/s); });
test('native resolver rejects a wrong current dispatch pointer', () => { const root = nativeFixture({ latestDispatch: { messageId: 'ORCH-000035' } }); try { nativeRejects(root); } finally { rmSync(root, { recursive: true, force: true }); } });
test('native resolver rejects an Architect prompt pointer mismatch', () => { const root = nativeFixture({ latestPrompt: { promptPath: 'evidence/prompts/ORCH-000035.md' } }); try { nativeRejects(root); } finally { rmSync(root, { recursive: true, force: true }); } });
test('native resolver rejects an unauthorized Architect decision', () => { const root = nativeFixture({ decision: { decision: 'NO NEW REPORT' } }); try { nativeRejects(root); } finally { rmSync(root, { recursive: true, force: true }); } });
test('native resolver rejects target-role mismatch in the current dispatch', () => { const root = nativeFixture({ latestDispatch: { targetRole: 'curator' } }); try { nativeRejects(root); } finally { rmSync(root, { recursive: true, force: true }); } });
test('native resolver rejects a missing ref', () => { const root = nativeFixture(); try { assert.throws(() => nativeRun(root, { ref: 'missing-ref' }), /GITHUB_DISPATCH_LOCATOR_REJECTED/); } finally { rmSync(root, { recursive: true, force: true }); } });
test('native resolver does not contact browser ports or execute the prompt', () => { const root = nativeFixture(); try { const result = nativeRun(root); assert.equal(result.messageId, 'ORCH-000036'); assert.deepEqual(result.canonicalPromptBytes, nativePrompt); } finally { rmSync(root, { recursive: true, force: true }); } });
test('native resolver CLI output is explicitly bounded', () => { const source = readFileSync(new URL('../src/browser-relay/worker-relay.js', import.meta.url), 'utf8'); assert.match(source, /--repo-root|repo-root/); assert.match(source, /writeFileSync\(path\.resolve\(args\.output\)/); });
test('native resolver preserves the legacy delivery contract alongside native resolution', () => { const source = readFileSync(new URL('../src/browser-relay/worker-relay.js', import.meta.url), 'utf8'); assert.match(source, /validateWorkerDeliveryBundle/); assert.match(source, /resolveGithubDispatchLocator/); });
test('native resolver returns structured resolution without automatic execution', () => { const root = nativeFixture(); try { const result = nativeRun(root); assert.equal(typeof result.ref, 'string'); assert.equal(result.canonicalPromptPath, 'evidence/prompts/ORCH-000036.md'); assert.equal(result.canonicalPromptBytes instanceof Buffer, true); } finally { rmSync(root, { recursive: true, force: true }); } });

function watcherFixture(overrides = {}) {
  const root = nativeFixture(overrides);
  const writeJson = (p, value) => { const target = path.join(root, p); mkdirSync(path.dirname(target), { recursive: true }); writeFileSync(target, JSON.stringify(value)); };
  const authority = { authorityId: 'AUTH-WATCHER', authoritySha256: 'a'.repeat(64), workerRole: 'executor' };
  const registration = { registrationId: 'REG-WATCHER', registrationSha256: 'b'.repeat(64), authorityId: authority.authorityId, workerRole: 'executor' };
  writeJson('evidence/current/worker/executor/LATEST_AUTHORITY.json', { recordId: authority.authorityId, recordSha256: authority.authoritySha256 });
  writeJson('evidence/current/worker/executor/LATEST_REGISTRATION.json', { recordId: registration.registrationId, recordSha256: registration.registrationSha256 });
  writeJson('evidence/worker-sessions/authorities/executor/AUTH-WATCHER.json', authority);
  writeJson('evidence/worker-sessions/registrations/executor/REG-WATCHER.json', registration);
  writeJson('evidence/current/RELAY_CONTROL.json', { recordId: 'CONTROL', state: 'ACTIVE' });
  writeJson('evidence/architect-sessions/controls/CONTROL.json', { recordId: 'CONTROL', state: 'ACTIVE' });
  nativeGit(root, 'add', '.'); nativeGit(root, 'commit', '-m', 'watcher fixture');
  return { root, authority, registration };
}
function watcherRun(f, extra = {}) { return evaluateDispatchWatcher({ repoRoot: f.root, ref: 'main', workerRole: 'executor', authority: f.authority, registration: f.registration, pollResult: { locatorText: nativeLocator, ...extra } }); }
function watcherClose(f) { rmSync(f.root, { recursive: true, force: true }); }

test('eligible current dispatch produces one candidate', () => { const f = watcherFixture(); try { const out = watcherRun(f); assert.equal(out.classification, 'ELIGIBLE_DISPATCH_CANDIDATE'); assert.equal(out.candidate.nextAction, 'PREPARE_DURABLE_INTENT'); } finally { watcherClose(f); } });
test('watcher locator is deterministic', () => { const f = watcherFixture(); try { const a = watcherRun(f).candidate; const b = watcherRun(f).candidate; assert.equal(a.deliveryPayloadText, b.deliveryPayloadText); assert.equal(a.deliveryPayloadSha256, b.deliveryPayloadSha256); } finally { watcherClose(f); } });
test('candidate binds the captured Git ref', () => { const f = watcherFixture(); try { const out = watcherRun(f); assert.match(out.candidate.capturedRef, /^[0-9a-f]{40}$/); } finally { watcherClose(f); } });
test('candidate binds authority and registration identity', () => { const f = watcherFixture(); try { const c = watcherRun(f).candidate; assert.equal(c.workerAuthorityId, 'AUTH-WATCHER'); assert.equal(c.workerRegistrationId, 'REG-WATCHER'); } finally { watcherClose(f); } });
test('canonical prompt body is absent from the locator payload', () => { const f = watcherFixture(); try { const c = watcherRun(f).candidate; assert.equal(c.deliveryPayloadText.includes(nativePrompt.toString()), false); assert.equal(c.deliveryPayloadKind, GITHUB_DISPATCH_LOCATOR_PROTOCOL); } finally { watcherClose(f); } });
test('wrong target role is rejected', () => { const f = watcherFixture({ latestDispatch: { targetRole: 'documentation_curator' } }); try { assert.equal(watcherRun(f).classification, 'REJECTED'); } finally { watcherClose(f); } });
test('non-relay-eligible dispatch is rejected', () => { const f = watcherFixture({ dispatch: { dispatchState: 'DRAFT' }, latestDispatch: { dispatchState: 'DRAFT' } }); try { assert.equal(watcherRun(f).reasonCodes[0], 'DISPATCH_NOT_RELAY_ELIGIBLE'); } finally { watcherClose(f); } });
test('Architect decision mismatch is rejected', () => { const f = watcherFixture({ decision: { nextCanonicalMessageId: 'ORCH-000035' } }); try { assert.ok(['NATIVE_RESOLVER_REJECTED', 'DISPATCH_POINTER_MISMATCH'].includes(watcherRun(f).reasonCodes[0])); } finally { watcherClose(f); } });
test('prompt pointer or hash mismatch is rejected', () => { const f = watcherFixture({ latestPrompt: { promptSha256: '0'.repeat(64) } }); try { assert.equal(watcherRun(f).classification, 'REJECTED'); } finally { watcherClose(f); } });
test('suppressing control blocks a candidate', () => { const f = watcherFixture(); try { const out = watcherRun(f, { control: 'STOP' }); assert.equal(out.reasonCodes[0], 'CONTROL_SUPPRESSED'); assert.equal(out.browserContacts, 0); } finally { watcherClose(f); } });
test('unresolved delivery blocks retry', () => { const f = watcherFixture(); try { assert.equal(watcherRun(f, { deliveryState: 'AMBIGUOUS' }).reasonCodes[0], 'UNRESOLVED_DELIVERY_BLOCKS_RETRY'); } finally { watcherClose(f); } });
test('already-consumed dispatch does not produce a second candidate', () => { const f = watcherFixture(); try { assert.equal(watcherRun(f, { consumed: true }).reasonCodes[0], 'DISPATCH_ALREADY_CONSUMED'); } finally { watcherClose(f); } });
test('remote advance requires reevaluation', () => { const f = watcherFixture(); try { assert.equal(watcherRun(f, { remoteAdvance: true }).reasonCodes[0], 'REMOTE_ADVANCE_REQUIRES_REEVALUATION'); } finally { watcherClose(f); } });
test('older dispatch fallback is prohibited', () => { const f = watcherFixture(); try { assert.equal(watcherRun(f, { olderDispatch: true }).reasonCodes[0], 'OLDER_DISPATCH_FALLBACK_PROHIBITED'); } finally { watcherClose(f); } });
test('only one worker mutation stream is allowed', () => { const f = watcherFixture(); try { assert.equal(watcherRun(f, { workerMutationInFlight: true }).reasonCodes[0], 'WORKER_MUTATION_STREAM_BUSY'); } finally { watcherClose(f); } });
test('result wait uses GitHub result evidence only', () => { const f = watcherFixture(); try { const out = evaluateDispatchWatcher({ repoRoot: f.root, ref: 'main', workerRole: 'executor', authority: f.authority, registration: f.registration, currentState: 'RESULT_WAIT', pollResult: { locatorText: nativeLocator, deliveryId: 'DELIVERY-1' }, resultEvidence: { deliveryId: 'DELIVERY-1', dispatchId: 'DISPATCH-000036', messageId: 'ORCH-000036', status: 'PENDING' } }); assert.equal(out.classification, 'WAITING_FOR_GITHUB_RESULT'); } finally { watcherClose(f); } });
test('assistant response DOM is never required', () => { const f = watcherFixture(); try { const out = watcherRun(f); assert.equal(out.classification, 'ELIGIBLE_DISPATCH_CANDIDATE'); assert.equal(Object.prototype.hasOwnProperty.call(out, 'responseDom'), false); } finally { watcherClose(f); } });
test('valid worker result produces one planned Architect doorbell', () => { const f = watcherFixture(); try { const out = evaluateDispatchWatcher({ repoRoot: f.root, ref: 'main', workerRole: 'executor', authority: f.authority, registration: f.registration, currentState: 'RESULT_WAIT', pollResult: { locatorText: nativeLocator, deliveryId: 'DELIVERY-1' }, resultEvidence: { deliveryId: 'DELIVERY-1', dispatchId: 'DISPATCH-000036', messageId: 'ORCH-000036', status: 'SENT' } }); assert.equal(out.classification, 'ARCHITECT_DOORBELL_PLANNED'); assert.equal(out.doorbellText, 'verify & next'); } finally { watcherClose(f); } });
test('planned doorbell text is exactly verify & next', () => { const f = watcherFixture(); try { const out = evaluateDispatchWatcher({ repoRoot: f.root, ref: 'main', workerRole: 'executor', authority: f.authority, registration: f.registration, currentState: 'RESULT_WAIT', pollResult: { locatorText: nativeLocator, deliveryId: 'DELIVERY-2' }, resultEvidence: { deliveryId: 'DELIVERY-2', dispatchId: 'DISPATCH-000036', messageId: 'ORCH-000036', status: 'SENT' } }); assert.deepEqual(Object.keys(out).filter((x) => x === 'doorbellText'), ['doorbellText']); assert.equal(out.doorbellText, 'verify & next'); } finally { watcherClose(f); } });
test('watcher evaluation performs zero browser or GitHub mutation', () => { const f = watcherFixture(); try { const out = watcherRun(f); assert.equal(out.browserContacts, 0); assert.equal(out.githubMutation, 0); } finally { watcherClose(f); } });

const cycleCandidate = { dispatchId: 'DISPATCH-CYCLE', messageId: 'ORCH-CYCLE', workerRole: 'executor', workerAuthorityId: 'AUTH-CYCLE', workerRegistrationId: 'REG-CYCLE', capturedRef: 'c'.repeat(40), canonicalPromptPath: 'evidence/prompts/ORCH-CYCLE.md', canonicalPromptSha256: 'd'.repeat(64), deliveryPayloadKind: GITHUB_DISPATCH_LOCATOR_PROTOCOL, deliveryPayloadText: 'execute github dispatch nakfreeajer/affotech-agent-orchestrator-evidence DISPATCH-CYCLE', deliveryPayloadSha256: hash('execute github dispatch nakfreeajer/affotech-agent-orchestrator-evidence DISPATCH-CYCLE'), deliveryPayloadByteCount: Buffer.byteLength('execute github dispatch nakfreeajer/affotech-agent-orchestrator-evidence DISPATCH-CYCLE'), nextAction: 'PREPARE_DURABLE_INTENT' };
const cycleEvaluation = { watcherState: 'CANDIDATE_READY', classification: 'ELIGIBLE_DISPATCH_CANDIDATE', candidate: cycleCandidate };
const cycleArgs = (overrides = {}) => ({ repoRoot: 'unused-injected-repo', workerRole: 'executor', workerAuthority: { authorityId: 'AUTH-CYCLE' }, workerRegistration: { registrationId: 'REG-CYCLE' }, architectAuthority: { authorityId: 'ARCH-AUTH' }, architectRegistration: { registrationId: 'ARCH-REG' }, deliveryId: 'DELIVERY-CYCLE', watcherResult: cycleEvaluation, deliveryPersistence: { persistAndReadBack: (x) => x }, workerSendAdapter: () => ({ outcome: 'SENT', sendActionCount: 1, composerText: '', responseDomRead: false }), workerResultAdapter: () => ({ status: 'SENT', workerRole: 'executor', dispatchId: 'DISPATCH-CYCLE', messageId: 'ORCH-CYCLE', deliveryId: 'DELIVERY-CYCLE' }), architectTriggerPersistence: { persistAndReadBack: (x) => x }, architectSendAdapter: () => ({ outcome: 'SENT', sendActionCount: 1, composerText: '', responseDomRead: false }), ...overrides });

test('eligible candidate advances to intent preparation', () => { const out = runAutomaticRelayCycle(cycleArgs({ workerSendAdapter: undefined })); assert.equal(out.cycleState, 'INTENT_REQUIRED'); });
test('intent contains exact compact locator binding', () => { let saved; const out = runAutomaticRelayCycle(cycleArgs({ deliveryPersistence: { persistAndReadBack: (x) => { saved = x; return x; } }, workerSendAdapter: () => ({ outcome: 'FAILED_BEFORE_SEND' }) })); assert.equal(out.classification, 'FAILED_BEFORE_SEND'); assert.equal(saved.deliveryPayloadKind, GITHUB_DISPATCH_LOCATOR_PROTOCOL); assert.equal(saved.deliveryPayloadText, cycleCandidate.deliveryPayloadText); assert.equal(saved.state, 'ARMED'); });
test('canonical prompt body is absent from delivery payload', () => { let sent; runAutomaticRelayCycle(cycleArgs({ workerSendAdapter: (x) => { sent = x.payloadText; return { outcome: 'FAILED_BEFORE_SEND' }; } })); assert.equal(sent.includes('DISPATCH-CYCLE'), true); assert.equal(sent.includes('ORCH-CYCLE'), false); });
test('durable intent read-back is required before worker send', () => { let sends = 0; const out = runAutomaticRelayCycle(cycleArgs({ deliveryPersistence: { persistAndReadBack: (x) => ({ ...x, deliveryId: 'OTHER' }) }, workerSendAdapter: () => { sends += 1; return { outcome: 'SENT' }; } })); assert.equal(out.reasonCodes[0], 'INTENT_READBACK_MISMATCH'); assert.equal(sends, 0); });
test('failed intent persistence keeps worker send count zero', () => { let sends = 0; const out = runAutomaticRelayCycle(cycleArgs({ deliveryPersistence: { persistAndReadBack: () => { throw new Error('persist'); } }, workerSendAdapter: () => { sends += 1; return { outcome: 'SENT' }; } })); assert.equal(out.reasonCodes[0], 'INTENT_PERSISTENCE_FAILED'); assert.equal(sends, 0); });
test('confirmed intent permits exactly one worker send', () => { let sends = 0; const out = runAutomaticRelayCycle(cycleArgs({ workerSendAdapter: () => { sends += 1; return { outcome: 'SENT', sendActionCount: 1, composerText: '' }; } })); assert.equal(out.cycleState, 'DOORBELL_SENT'); assert.equal(sends, 1); });
test('SENT requires structural composer empty', () => { const out = runAutomaticRelayCycle(cycleArgs({ workerSendAdapter: () => ({ sendActionCount: 1, composerText: 'still present' }) })); assert.equal(out.classification, 'AMBIGUOUS'); assert.equal(out.cycleState, 'RECONCILIATION_REQUIRED'); });
test('non-empty composer becomes AMBIGUOUS', () => { const out = runAutomaticRelayCycle(cycleArgs({ workerSendAdapter: () => ({ outcome: 'SENT', sendActionCount: 1, composerText: 'not empty' }) })); assert.equal(out.classification, 'AMBIGUOUS'); assert.equal(out.retryAuthorized, false); });
test('timeout or uncertain worker send becomes AMBIGUOUS', () => { const out = runAutomaticRelayCycle(cycleArgs({ workerSendAdapter: () => ({ timeout: true }) })); assert.equal(out.classification, 'AMBIGUOUS'); assert.equal(out.workerSendCount, 1); });
test('AMBIGUOUS worker send forbids retry', () => { const out = runAutomaticRelayCycle(cycleArgs({ workerSendAdapter: () => ({ outcome: 'AMBIGUOUS' }) })); assert.equal(out.retryAuthorized, false); assert.equal(out.cycleState, 'RECONCILIATION_REQUIRED'); });
test('FAILED_BEFORE_SEND performs no result wait', () => { let reads = 0; const out = runAutomaticRelayCycle(cycleArgs({ workerSendAdapter: () => ({ outcome: 'FAILED_BEFORE_SEND' }), workerResultAdapter: () => { reads += 1; return null; } })); assert.equal(out.cycleState, 'FAILED_BEFORE_SEND'); assert.equal(reads, 0); });
test('SENT with no GitHub result enters RESULT_WAIT', () => { const out = runAutomaticRelayCycle(cycleArgs({ workerResultAdapter: () => undefined })); assert.equal(out.cycleState, 'RESULT_WAIT'); assert.equal(out.architectSendCount, 0); });
test('worker assistant DOM is never queried', () => { let dom = false; const out = runAutomaticRelayCycle(cycleArgs({ workerSendAdapter: () => ({ outcome: 'SENT', sendActionCount: 1, composerText: '' }), workerResultAdapter: () => ({ status: 'SENT', workerRole: 'executor', dispatchId: 'DISPATCH-CYCLE', messageId: 'ORCH-CYCLE', deliveryId: 'DELIVERY-CYCLE', get responseDom() { dom = true; return null; } }) })); assert.equal(out.cycleState, 'DOORBELL_SENT'); assert.equal(dom, false); });
test('valid GitHub worker result is accepted', () => { const out = runAutomaticRelayCycle(cycleArgs()); assert.equal(out.cycleState, 'DOORBELL_SENT'); });
test('mismatched worker result fails closed', () => { const out = runAutomaticRelayCycle(cycleArgs({ workerResultAdapter: () => ({ status: 'SENT', workerRole: 'executor', dispatchId: 'WRONG', messageId: 'ORCH-CYCLE', deliveryId: 'DELIVERY-CYCLE' }) })); assert.equal(out.reasonCodes[0], 'WORKER_RESULT_BINDING_INVALID'); });
test('valid result prepares one Architect trigger intent', () => { let trigger; runAutomaticRelayCycle(cycleArgs({ architectTriggerPersistence: { persistAndReadBack: (x) => { trigger = x; return x; } } })); assert.equal(trigger.state, 'ARMED'); assert.equal(trigger.payloadText, 'verify & next'); });
test('trigger intent read-back is required before Architect send', () => { let sends = 0; const out = runAutomaticRelayCycle(cycleArgs({ architectTriggerPersistence: { persistAndReadBack: (x) => ({ ...x, triggerId: 'OTHER' }) }, architectSendAdapter: () => { sends += 1; return { outcome: 'SENT' }; } })); assert.equal(out.reasonCodes[0], 'TRIGGER_READBACK_MISMATCH'); assert.equal(sends, 0); });
test('Architect doorbell text is exactly verify & next', () => { let payload; runAutomaticRelayCycle(cycleArgs({ architectSendAdapter: (x) => { payload = x.payloadText; return { outcome: 'SENT', sendActionCount: 1, composerText: '' }; } })); assert.equal(payload, 'verify & next'); });
test('Architect send is invoked at most once', () => { let sends = 0; const out = runAutomaticRelayCycle(cycleArgs({ architectSendAdapter: () => { sends += 1; return { outcome: 'SENT', sendActionCount: 1, composerText: '' }; } })); assert.equal(out.architectSendCount, 1); assert.equal(sends, 1); });
test('Architect response DOM is never queried', () => { let dom = false; const out = runAutomaticRelayCycle(cycleArgs({ architectSendAdapter: () => ({ outcome: 'SENT', sendActionCount: 1, composerText: '', get responseDom() { dom = true; return null; } }) })); assert.equal(out.cycleState, 'DOORBELL_SENT'); assert.equal(dom, false); });
test('ambiguous Architect send forbids blind retry', () => { const out = runAutomaticRelayCycle(cycleArgs({ architectSendAdapter: () => ({ timeout: true }) })); assert.equal(out.cycleState, 'RECONCILIATION_REQUIRED'); assert.equal(out.retryAuthorized, false); });
test('suppressing control blocks every later mutation phase', () => { let sends = 0; const out = runAutomaticRelayCycle(cycleArgs({ controlState: 'STOP', workerSendAdapter: () => { sends += 1; return { outcome: 'SENT' }; } })); assert.equal(out.reasonCodes[0], 'CONTROL_SUPPRESSED'); assert.equal(sends, 0); });
test('one worker mutation stream is enforced', () => { let sends = 0; const out = runAutomaticRelayCycle(cycleArgs({ workerMutationInFlight: true, workerSendAdapter: () => { sends += 1; return { outcome: 'SENT' }; } })); assert.equal(out.reasonCodes[0], 'WORKER_MUTATION_STREAM_BUSY'); assert.equal(sends, 0); });
test('full bounded cycle uses injected adapters and performs no real mutation', () => { const calls = []; const out = runAutomaticRelayCycle(cycleArgs({ deliveryPersistence: { persistAndReadBack: (x) => { calls.push('persist-intent'); return x; } }, workerSendAdapter: (x) => { calls.push(`worker:${x.payloadText}`); return { outcome: 'SENT', sendActionCount: 1, composerText: '' }; }, workerResultAdapter: () => { calls.push('read-result'); return { status: 'SENT', workerRole: 'executor', dispatchId: 'DISPATCH-CYCLE', messageId: 'ORCH-CYCLE', deliveryId: 'DELIVERY-CYCLE' }; }, architectTriggerPersistence: { persistAndReadBack: (x) => { calls.push('persist-trigger'); return x; } }, architectSendAdapter: (x) => { calls.push(`architect:${x.payloadText}`); return { outcome: 'SENT', sendActionCount: 1, composerText: '' }; } })); assert.equal(out.cycleState, 'DOORBELL_SENT'); assert.deepEqual(calls, ['persist-intent', `worker:${cycleCandidate.deliveryPayloadText}`, 'read-result', 'persist-trigger', 'architect:verify & next']); assert.equal(out.browserContacts, 0); assert.equal(out.githubMutation, 0); });

test('watcher rejects unsupported dispatch schema before candidate/send', () => { const f = watcherFixture({ dispatch: { schemaVersion: '2.0' }, latestDispatch: { schemaVersion: '2.0' } }); try { assert.equal(watcherRun(f).reasonCodes[0], 'UNSUPPORTED_SCHEMA_VERSION'); } finally { watcherClose(f); } });
test('watcher rejects unknown dispatch record kind before candidate/send', () => { const f = watcherFixture({ dispatch: { recordType: 'UNKNOWN' }, latestDispatch: { recordType: 'UNKNOWN' } }); try { assert.equal(watcherRun(f).reasonCodes[0], 'UNKNOWN_RECORD_KIND'); } finally { watcherClose(f); } });
test('watcher rejects foreign PUB-* canonical dispatch identity without confusing GH-PUB-* evidence IDs', () => { const f = watcherFixture({ dispatch: { messageId: 'PUB-1' }, latestDispatch: { messageId: 'PUB-1' } }); try { assert.equal(watcherRun(f).reasonCodes[0], 'FOREIGN_PROTOCOL_FAMILY'); } finally { watcherClose(f); } });
test('accepted ORCH-*/DISPATCH-* schemaVersion 1.0 candidate behavior remains unchanged', () => { const f = watcherFixture(); try { assert.equal(watcherRun(f).classification, 'ELIGIBLE_DISPATCH_CANDIDATE'); } finally { watcherClose(f); } });
test('incompatible durable worker-result record cannot advance result processing', () => { const f = watcherFixture(); try { const out = watcherRun(f, { deliveryId: 'DELIVERY-1' }); const result = evaluateDispatchWatcher({ repoRoot: f.root, ref: 'main', workerRole: 'executor', authority: f.authority, registration: f.registration, currentState: 'RESULT_WAIT', pollResult: { locatorText: nativeLocator, deliveryId: 'DELIVERY-1' }, resultEvidence: { schemaVersion: '9.0', recordType: 'WORKER_RESULT', deliveryId: 'DELIVERY-1', dispatchId: 'DISPATCH-000036', messageId: 'ORCH-000036', status: 'SENT' } }); assert.equal(result.reasonCodes[0], 'UNSUPPORTED_SCHEMA_VERSION'); } finally { watcherClose(f); } });
test('incompatible Architect-trigger/reconciliation record fails closed', () => { assert.equal(validateArchitectReconciliationCompatibility({ schemaVersion: '2.0', recordType: 'ARCHITECT_TRIGGER_RECONCILIATION' }).reasonCodes[0], 'UNSUPPORTED_SCHEMA_VERSION'); });
test('ambiguous repeated-content reconciliation without durable correlation returns insufficient evidence and authorizes no retry/send', () => { const out = evaluateCorrelationEvidence({ sourceMessageId: 'ORCH-1', dispatchId: 'DISPATCH-1', payloadSha256: 'same' }); assert.equal(out.classification, 'INSUFFICIENT_CORRELATION_EVIDENCE'); assert.equal(out.retryAuthorized, false); });
test('correlation-sufficient synthetic reconciliation is accepted by the deterministic gate while assistant/response DOM remains irrelevant', () => { const out = evaluateCorrelationEvidence({ operationId: 'op', sourceMessageId: 'ORCH-1', dispatchId: 'DISPATCH-1', targetId: 'registered-9333', payloadSha256: 'payload', preAttemptBoundary: 'boundary', preAttemptBoundarySha256: 'boundary-hash', attemptOrdinal: 1 }); assert.equal(out.classification, 'CORRELATION_SUFFICIENT'); assert.equal(out.retryAuthorized, false); });

const architectBoundaryInput = (userMessages = [{ role: 'user', text: 'historical' }, { role: 'assistant', text: 'ignored' }]) => ({ intentId: 'INTENT-1', triggerId: 'TRIGGER-1', sourceMessageId: 'ORCH-000046', dispatchId: 'DISPATCH-000046', authorityId: 'ARCH-AUTH-1', registrationId: 'ARCH-REG-1', relayPort: 9333, conversationId: 'CONV-1', payloadText: 'verify & next', userMessages });
test('boundary binds exact target/lineage/payload identities', () => { const b = buildArchitectPreSendBoundary(architectBoundaryInput()); assert.equal(b.authorityId, 'ARCH-AUTH-1'); assert.equal(b.registrationId, 'ARCH-REG-1'); assert.equal(b.sourceMessageId, 'ORCH-000046'); assert.equal(b.dispatchId, 'DISPATCH-000046'); assert.equal(b.payloadText, 'verify & next'); assert.equal(validateArchitectPreSendBoundary(b).valid, true); });
test('captures total and matching USER-message counts', () => { const b = buildArchitectPreSendBoundary(architectBoundaryInput([{ role: 'user', text: 'verify & next' }, { role: 'user', text: 'other' }, { role: 'assistant', text: 'verify & next' }])); assert.equal(b.totalUserMessageCount, 2); assert.equal(b.matchingUserMessageCount, 1); });
test('includes deterministic pre-boundary fingerprint', () => { const a = buildArchitectPreSendBoundary(architectBoundaryInput()); const b = buildArchitectPreSendBoundary(architectBoundaryInput()); assert.equal(a.userMessageBoundaryFingerprint, b.userMessageBoundaryFingerprint); assert.match(a.userMessageBoundaryFingerprint, /^[0-9a-f]{64}$/); });
test('missing boundary fails before send eligibility', () => { const out = evaluateArchitectPreSendBoundary({ observation: { userMessages: [] } }); assert.equal(out.sendAuthorized, false); assert.equal(out.classification, 'INSUFFICIENT_CORRELATION_EVIDENCE'); });
test('trigger intent not send-eligible until complete boundary exists', () => { const b = buildArchitectPreSendBoundary(architectBoundaryInput()); assert.equal(validateArchitectPreSendBoundary(b).sendAuthorized, false); assert.equal(evaluateArchitectPreSendBoundary({ boundary: b, observation: { userMessages: architectBoundaryInput().userMessages } }).sendAuthorized, true); });
test('target/boundary advancement detected as stale', () => { const b = buildArchitectPreSendBoundary(architectBoundaryInput()); const out = evaluateArchitectPreSendBoundary({ boundary: b, observation: { userMessages: [{ role: 'user', text: 'advanced' }] } }); assert.equal(out.classification, 'CORRELATION_MISMATCH'); assert.equal(out.sendAuthorized, false); });
test('exact PRE→POST +1/+1 confirms one specific repeated payload', () => { const b = buildArchitectPreSendBoundary(architectBoundaryInput([{ role: 'user', text: 'verify & next' }])); const out = evaluateArchitectPostSend({ preBoundary: b, postObservation: { userMessages: [{ role: 'user', text: 'verify & next' }, { role: 'user', text: 'verify & next' }] }, newlyAppendedUserMessage: 'verify & next' }); assert.equal(out.classification, 'SENT'); assert.equal(out.confirmedSendCount, 1); });
test('historical identical payloads do not block valid +1/+1 confirmation', () => { const b = buildArchitectPreSendBoundary(architectBoundaryInput([{ role: 'user', text: 'verify & next' }, { role: 'user', text: 'verify & next' }])); const out = evaluateArchitectPostSend({ preBoundary: b, postObservation: { userMessages: [{ role: 'user', text: 'verify & next' }, { role: 'user', text: 'verify & next' }, { role: 'user', text: 'verify & next' }] }, newlyAppendedUserMessage: 'verify & next' }); assert.equal(out.classification, 'SENT'); });
test('zero delta after attempted send not confirmed/no retry', () => { const b = buildArchitectPreSendBoundary(architectBoundaryInput()); const out = evaluateArchitectPostSend({ preBoundary: b, postObservation: { userMessages: architectBoundaryInput().userMessages }, newlyAppendedUserMessage: undefined }); assert.equal(out.confirmedSendCount, 0); assert.equal(out.retryAuthorized, false); assert.equal(out.reconciliationRequired, true); });
test('delta >1 or target/payload mismatch => correlation mismatch/reconciliation/no retry', () => { const b = buildArchitectPreSendBoundary(architectBoundaryInput()); const out = evaluateArchitectPostSend({ preBoundary: b, postObservation: { userMessages: [{ role: 'user', text: 'a' }, { role: 'user', text: 'b' }, { role: 'user', text: 'verify & next' }] }, newlyAppendedUserMessage: 'verify & next' }); assert.equal(out.classification, 'CORRELATION_MISMATCH'); assert.equal(out.retryAuthorized, false); assert.equal(out.reconciliationRequired, true); });
test('assistant-response text absent from inputs and responseDomRead=false', () => { const b = buildArchitectPreSendBoundary(architectBoundaryInput([{ role: 'user', text: 'x' }])); const out = evaluateArchitectPostSend({ preBoundary: b, postObservation: { userMessages: [{ role: 'user', text: 'x' }, { role: 'user', text: 'verify & next' }], assistantResponseText: 'must not be read' }, newlyAppendedUserMessage: 'verify & next' }); assert.equal(out.responseDomRead, false); assert.equal(out.classification, 'SENT'); });
test('complete persisted boundary reaches correlation-sufficient gate; missing/stale remains insufficient/no-send/no-retry', () => { const b = buildArchitectPreSendBoundary(architectBoundaryInput()); const ready = evaluateArchitectPreSendBoundary({ boundary: b, observation: { userMessages: architectBoundaryInput().userMessages } }); const stale = evaluateArchitectPreSendBoundary({ boundary: b, observation: { userMessages: [{ role: 'user', text: 'changed' }] } }); assert.equal(ready.sendAuthorized, true); assert.equal(stale.sendAuthorized, false); assert.equal(stale.retryAuthorized, false); });
