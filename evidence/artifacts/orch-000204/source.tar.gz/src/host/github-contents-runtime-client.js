import crypto from 'node:crypto';

const METHODS = Object.freeze(['getBranchHead', 'readJsonAtRef', 'readJsonCurrent', 'createJson', 'updateJsonCas']);
const object = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
const exact = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const sha256 = (value) => crypto.createHash('sha256').update(value, 'utf8').digest('hex');
const serialized = (value) => `${JSON.stringify(value, null, 2)}\n`;
const safeError = (code, extra = {}) => Object.assign(new Error(code), { code, ...extra });
const notFound = (error) => error?.code === 'NOT_FOUND' || error?.status === 404 || error?.statusCode === 404 || error?.absent === true;
const errorDetails = (error) => ({ httpStatus: Number.isInteger(error?.status) ? error.status : Number.isInteger(error?.statusCode) ? error.statusCode : null, reasonCode: typeof error?.reasonCode === 'string' ? error.reasonCode : typeof error?.code === 'string' ? error.code : null });

function validateOptions(options) {
  if (!object(options) || typeof options.repositoryFullName !== 'string' || !options.repositoryFullName || typeof options.branch !== 'string' || !options.branch || typeof options.request !== 'function') {
    throw new TypeError('repositoryFullName, branch, and injected request are required');
  }
}

function pathFor(repositoryFullName, path, ref) {
  const encodedPath = path.split('/').map((part) => encodeURIComponent(part)).join('/');
  return `/repos/${repositoryFullName}/contents/${encodedPath}?ref=${encodeURIComponent(ref)}`;
}

function decodeContent(response) {
  if (typeof response?.content !== 'string') throw safeError('CONTENT_INVALID');
  try {
    const text = response.encoding === 'base64'
      ? Buffer.from(response.content.replace(/\s/g, ''), 'base64').toString('utf8')
      : response.content;
    return JSON.parse(text);
  } catch {
    throw safeError('JSON_INVALID');
  }
}

function mutationBody(path, value, branch, sha, message) {
  const body = { message: message(path), content: Buffer.from(serialized(value), 'utf8').toString('base64'), branch };
  if (sha !== null && sha !== undefined) body.sha = sha;
  return body;
}

export function createGitHubContentsRuntimeClient(options = {}) {
  validateOptions(options);
  const { repositoryFullName, branch, request } = options;
  const message = typeof options.commitMessage === 'function'
    ? options.commitMessage
    : (path) => `orchestrator: update ${path}`;
  const call = async (method, path, body) => request({ method, path, body });
  const getBranchHead = async (input = {}) => {
    const repo = input.repositoryFullName ?? repositoryFullName;
    const targetBranch = input.branch ?? branch;
    const response = await call('GET', `/repos/${repo}/git/ref/heads/${encodeURIComponent(targetBranch)}`);
    const sha = response?.object?.sha ?? response?.sha;
    if (typeof sha !== 'string' || !sha) throw safeError('BRANCH_HEAD_INVALID');
    return { ref: sha, sha };
  };
  const readJsonAtRef = async (path, ref) => {
    if (typeof path !== 'string' || !path || typeof ref !== 'string' || !ref) throw safeError('READ_ARGUMENT_INVALID');
    const response = await call('GET', pathFor(repositoryFullName, path, ref));
    return { value: decodeContent(response), blobSha: response.sha ?? response.blobSha ?? null, ref };
  };
  const readJsonCurrent = async (path) => {
    const head = await getBranchHead();
    return readJsonAtRef(path, head.ref);
  };
  const reconcile = async (path, value) => {
    try {
      const current = await readJsonCurrent(path);
      return exact(current.value, value)
        ? { status: 'IDEMPOTENT', blobSha: current.blobSha, ref: current.ref, readbackAttempted: true, readbackStatus: 200, readbackReasonCode: null, readbackMatched: true }
        : { status: 'CONFLICT', reasonCode: 'EXISTING_CONTENT_CONFLICT', blobSha: current.blobSha, ref: current.ref, readbackAttempted: true, readbackStatus: 200, readbackReasonCode: 'EXISTING_CONTENT_CONFLICT', readbackMatched: false };
    } catch (error) {
      const details = errorDetails(error);
      if (notFound(error)) return { status: 'AMBIGUOUS', reasonCode: 'POST_MUTATION_ABSENT', readbackAttempted: true, readbackStatus: details.httpStatus ?? 404, readbackReasonCode: 'POST_MUTATION_ABSENT', readbackMatched: false };
      return { status: 'AMBIGUOUS', reasonCode: 'POST_MUTATION_RECONCILIATION_FAILED', readbackAttempted: true, readbackStatus: details.httpStatus, readbackReasonCode: 'POST_MUTATION_RECONCILIATION_FAILED', readbackMatched: false };
    }
  };
  const createJson = async (path, value) => {
    let current;
    try { current = await readJsonCurrent(path); }
    catch (error) { if (!notFound(error)) return { status: 'AMBIGUOUS', reasonCode: 'CREATE_PRECHECK_FAILED' }; }
    if (current) return exact(current.value, value)
      ? { status: 'IDEMPOTENT', blobSha: current.blobSha, ref: current.ref }
      : { status: 'CONFLICT', reasonCode: 'EXISTING_CONTENT_CONFLICT', blobSha: current.blobSha, ref: current.ref };
    let putResponse;
    try {
      putResponse = await call('PUT', `/repos/${repositoryFullName}/contents/${path.split('/').map((part) => encodeURIComponent(part)).join('/')}`, mutationBody(path, value, branch, null, message));
    } catch (error) {
      const details = errorDetails(error);
      return { ...(await reconcile(path, value)), createStatus: null, createReasonCode: details.reasonCode, createHttpStatus: details.httpStatus, createAcceptedForReadback: false };
    }
    const readback = await reconcile(path, value);
    return readback.status === 'IDEMPOTENT'
      ? { ...readback, status: 'CREATED', createStatus: Number.isInteger(putResponse?.status) ? putResponse.status : null, createReasonCode: null, createHttpStatus: Number.isInteger(putResponse?.status) ? putResponse.status : Number.isInteger(putResponse?.statusCode) ? putResponse.statusCode : null, createAcceptedForReadback: true }
      : { ...readback, createStatus: Number.isInteger(putResponse?.status) ? putResponse.status : null, createReasonCode: readback.reasonCode ?? null, createHttpStatus: Number.isInteger(putResponse?.status) ? putResponse.status : Number.isInteger(putResponse?.statusCode) ? putResponse.statusCode : null, createAcceptedForReadback: true };
  };
  const updateJsonCas = async (path, expectedSha, value) => {
    if (expectedSha === null || expectedSha === undefined) return createJson(path, value);
    if (typeof expectedSha !== 'string' || !expectedSha) return { status: 'CONFLICT', reasonCode: 'EXPECTED_SHA_INVALID' };
    try {
      await call('PUT', `/repos/${repositoryFullName}/contents/${path.split('/').map((part) => encodeURIComponent(part)).join('/')}`, mutationBody(path, value, branch, expectedSha, message));
    } catch (error) {
      if (error?.status === 409 || error?.status === 422 || error?.code === 'STALE_TARGET_SHA') return { status: 'CONFLICT', reasonCode: 'STALE_TARGET_SHA' };
      return reconcile(path, value);
    }
    const readback = await reconcile(path, value);
    return readback.status === 'IDEMPOTENT' ? { ...readback, status: 'UPDATED' } : readback;
  };
  return Object.freeze({ getBranchHead, readJsonAtRef, readJsonCurrent, createJson, updateJsonCas, sha256 });
}
